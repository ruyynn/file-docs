#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Report JSON Schema validation"""

from typing import Dict, Any, List, Optional
from datetime import datetime


class ReportSchema:
    """Lightweight JSON-schema for GhostIntel reports.

    Validates structure without requiring jsonschema library — keeps the
    dependency footprint small.
    """

    SCHEMA_VERSION = "3.0.0"

    SCHEMA = {
        "type": "object",
        "required": ["generated", "version", "tool", "results"],
        "properties": {
            "generated": {"type": "string", "format": "date-time"},
            "version": {"type": "string"},
            "tool": {"type": "string"},
            "target": {"type": "string"},
            "results": {"type": "object"},
            "correlation": {"type": "object"},
        },
    }

    REQUIRED_MODULE_FIELDS = {"module", "target", "data", "sources", "timestamp"}

    @classmethod
    def validate(cls, data: Dict[str, Any]) -> List[str]:
        """Return list of validation errors. Empty list = valid."""
        errors: List[str] = []

        if not isinstance(data, dict):
            return ["Root must be an object"]

        for field in cls.SCHEMA["required"]:
            if field not in data:
                errors.append(f"Missing required field: {field}")

        if "generated" in data:
            try:
                datetime.fromisoformat(str(data["generated"]).replace("Z", "+00:00"))
            except Exception:
                errors.append("Field 'generated' must be ISO-8601 datetime")

        if "version" in data and not isinstance(data["version"], str):
            errors.append("Field 'version' must be string")

        if "results" in data:
            if not isinstance(data["results"], dict):
                errors.append("Field 'results' must be object")
            else:
                for name, mod_result in data["results"].items():
                    if name.startswith("_"):
                        continue
                    if not isinstance(mod_result, dict):
                        errors.append(f"Module '{name}' must be object")
                        continue
                    for f in cls.REQUIRED_MODULE_FIELDS:
                        if f not in mod_result:
                            errors.append(
                                f"Module '{name}' missing field: {f}"
                            )
        return errors

    @classmethod
    def is_valid(cls, data: Dict[str, Any]) -> bool:
        return not cls.validate(data)

    @classmethod
    def wrap(cls, results: Dict[str, Any], target: Optional[str] = None,
             version: str = SCHEMA_VERSION) -> Dict[str, Any]:
        """Wrap raw results into a schema-compliant envelope."""
        return {
            "generated": datetime.now().isoformat(),
            "version": version,
            "tool": "GhostIntel",
            "target": target or "unknown",
            "results": results,
        }
