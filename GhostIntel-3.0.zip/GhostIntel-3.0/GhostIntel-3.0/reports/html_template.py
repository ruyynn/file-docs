#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - HTML Report Template

Clean, responsive single-file report with Chart.js dashboard.
No external CDN required for offline use (Chart.js inlined).
"""

import json
from datetime import datetime


# Chart.js minimal (CDN with offline fallback)
CHART_JS_CDN = "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GhostIntel Report - {{ target }}</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }

:root {
  --bg-primary:#0a0c0f;
  --bg-secondary:#14181c;
  --bg-tertiary:#1e2329;
  --bg-hover:#252d36;
  --text-primary:#e6e9ef;
  --text-secondary:#9aa3b4;
  --text-muted:#6b7485;
  --accent-cyan:#2dd4bf;
  --accent-green:#10b981;
  --accent-yellow:#f59e0b;
  --accent-orange:#f97316;
  --accent-red:#ef4444;
  --accent-purple:#a78bfa;
  --accent-blue:#3b82f6;
  --border-color:#2a3038;
  --border-light:#333b44;
  --success:#10b981;
  --warning:#f59e0b;
  --danger:#ef4444;
  --info:#3b82f6;
}

.light-theme {
  --bg-primary:#f3f4f6;
  --bg-secondary:#ffffff;
  --bg-tertiary:#f9fafb;
  --bg-hover:#e5e7eb;
  --text-primary:#111827;
  --text-secondary:#4b5563;
  --text-muted:#6b7280;
  --border-color:#e5e7eb;
  --border-light:#d1d5db;
}

body {
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
  background:var(--bg-primary);
  color:var(--text-primary);
  line-height:1.6;
  transition:background-color 0.3s,color 0.3s;
  min-height:100vh;
}

.container { max-width:1400px; margin:0 auto; padding:2rem; }

/* Header */
.report-header {
  background:var(--bg-secondary);
  border:1px solid var(--border-color);
  border-radius:12px;
  padding:2rem;
  margin-bottom:1.5rem;
  display:flex;
  justify-content:space-between;
  align-items:center;
  flex-wrap:wrap;
  gap:1rem;
}

.report-header h1 {
  font-size:1.75rem;
  color:var(--accent-cyan);
  margin-bottom:0.25rem;
}

.report-header .meta {
  color:var(--text-muted);
  font-size:0.875rem;
}

.theme-toggle {
  background:var(--bg-tertiary);
  color:var(--text-primary);
  border:1px solid var(--border-light);
  border-radius:8px;
  padding:0.5rem 1rem;
  cursor:pointer;
  font-size:0.875rem;
  transition:all 0.2s;
}

.theme-toggle:hover {
  background:var(--bg-hover);
}

/* Summary cards */
.summary-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
  gap:1rem;
  margin-bottom:1.5rem;
}

.summary-card {
  background:var(--bg-secondary);
  border:1px solid var(--border-color);
  border-radius:12px;
  padding:1.5rem;
  transition:transform 0.2s,border-color 0.2s;
}

.summary-card:hover {
  transform:translateY(-2px);
  border-color:var(--accent-cyan);
}

.summary-card .label {
  font-size:0.75rem;
  text-transform:uppercase;
  letter-spacing:0.05em;
  color:var(--text-muted);
  margin-bottom:0.5rem;
}

.summary-card .value {
  font-size:1.75rem;
  font-weight:700;
  color:var(--text-primary);
}

.summary-card .value.success { color:var(--success); }
.summary-card .value.warning { color:var(--warning); }
.summary-card .value.danger { color:var(--danger); }
.summary-card .value.info { color:var(--info); }

/* Dashboard grid */
.dashboard {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
  gap:1.5rem;
  margin-bottom:1.5rem;
}

.chart-card {
  background:var(--bg-secondary);
  border:1px solid var(--border-color);
  border-radius:12px;
  padding:1.5rem;
}

.chart-card h3 {
  font-size:1rem;
  color:var(--text-secondary);
  margin-bottom:1rem;
  text-transform:uppercase;
  letter-spacing:0.05em;
}

.chart-wrapper {
  position:relative;
  height:240px;
}

/* Risk gauge */
.risk-gauge {
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  height:100%;
}

.risk-circle {
  width:140px;
  height:140px;
  border-radius:50%;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:2.5rem;
  font-weight:700;
  border:8px solid;
  margin-bottom:1rem;
}

.risk-circle.low { border-color:var(--success); color:var(--success); }
.risk-circle.medium { border-color:var(--warning); color:var(--warning); }
.risk-circle.high { border-color:var(--accent-orange); color:var(--accent-orange); }
.risk-circle.critical { border-color:var(--danger); color:var(--danger); }

.risk-label {
  text-transform:uppercase;
  letter-spacing:0.1em;
  font-size:0.875rem;
  color:var(--text-muted);
}

/* Module sections */
.module-section {
  background:var(--bg-secondary);
  border:1px solid var(--border-color);
  border-radius:12px;
  margin-bottom:1rem;
  overflow:hidden;
}

.module-header {
  padding:1rem 1.5rem;
  cursor:pointer;
  display:flex;
  justify-content:space-between;
  align-items:center;
  background:var(--bg-tertiary);
  transition:background 0.2s;
}

.module-header:hover {
  background:var(--bg-hover);
}

.module-header h2 {
  font-size:1rem;
  text-transform:uppercase;
  letter-spacing:0.05em;
  color:var(--accent-cyan);
}

.module-toggle {
  color:var(--text-muted);
  transition:transform 0.2s;
}

.module-section.open .module-toggle {
  transform:rotate(90deg);
}

.module-body {
  padding:0;
  max-height:0;
  overflow:hidden;
  transition:max-height 0.3s ease,padding 0.3s ease;
}

.module-section.open .module-body {
  max-height:5000px;
  padding:1.5rem;
}

.module-body .data-row {
  display:grid;
  grid-template-columns:200px 1fr;
  gap:1rem;
  padding:0.5rem 0;
  border-bottom:1px solid var(--border-color);
}

.module-body .data-row:last-child {
  border-bottom:none;
}

.module-body .data-key {
  color:var(--text-muted);
  font-size:0.875rem;
  text-transform:capitalize;
}

.module-body .data-value {
  color:var(--text-primary);
  word-break:break-word;
}

.module-body .data-value a {
  color:var(--accent-blue);
  text-decoration:none;
}

.module-body .data-value a:hover {
  text-decoration:underline;
}

.module-body .badge {
  display:inline-block;
  padding:0.125rem 0.5rem;
  border-radius:4px;
  font-size:0.75rem;
  font-weight:600;
  margin-right:0.25rem;
}

.badge.success { background:rgba(16,185,129,0.2); color:var(--success); }
.badge.warning { background:rgba(245,158,11,0.2); color:var(--warning); }
.badge.danger { background:rgba(239,68,68,0.2); color:var(--danger); }
.badge.info { background:rgba(59,130,246,0.2); color:var(--info); }

.module-body ul {
  list-style:none;
  padding-left:0;
}

.module-body ul li {
  padding:0.25rem 0;
  border-bottom:1px solid var(--border-color);
}

.module-body ul li:last-child {
  border-bottom:none;
}

/* Footer */
.report-footer {
  text-align:center;
  padding:2rem;
  color:var(--text-muted);
  font-size:0.875rem;
  border-top:1px solid var(--border-color);
  margin-top:2rem;
}

.report-footer a {
  color:var(--accent-cyan);
  text-decoration:none;
}

/* Responsive */
@media (max-width:768px) {
  .container { padding:1rem; }
  .report-header { flex-direction:column; text-align:center; }
  .module-body .data-row {
    grid-template-columns:1fr;
    gap:0.25rem;
  }
}

/* Scrollbar */
::-webkit-scrollbar { width:8px; height:8px; }
::-webkit-scrollbar-track { background:var(--bg-primary); }
::-webkit-scrollbar-thumb { background:var(--border-light); border-radius:4px; }
::-webkit-scrollbar-thumb:hover { background:var(--text-muted); }
</style>
</head>
<body>
<div class="container">

<!-- Header -->
<div class="report-header">
  <div>
    <h1>GhostIntel v{{ version }}</h1>
    <div class="meta">
      Target: <strong style="color:var(--text-primary)">{{ target }}</strong>
      &middot; Generated: {{ timestamp }}
      &middot; {{ total_modules }} module(s)
    </div>
  </div>
  <button class="theme-toggle" onclick="toggleTheme()">Toggle theme</button>
</div>

<!-- Summary cards -->
<div class="summary-grid">
  <div class="summary-card">
    <div class="label">Modules Run</div>
    <div class="value info">{{ total_modules }}</div>
  </div>
  <div class="summary-card">
    <div class="label">Platforms Found</div>
    <div class="value success">{{ chart_data.platform_count }}</div>
  </div>
  <div class="summary-card">
    <div class="label">Breaches Detected</div>
    <div class="value danger">{{ chart_data.breach_count }}</div>
  </div>
  <div class="summary-card">
    <div class="label">Risk Score</div>
    <div class="value {{ 'critical' if chart_data.risk_score >= 70 else ('warning' if chart_data.risk_score >= 40 else 'success') }}">{{ chart_data.risk_score }}/100</div>
  </div>
</div>

<!-- Dashboard charts -->
{% if chart_data.category_distribution or chart_data.timeline %}
<div class="dashboard">
  {% if chart_data.category_distribution %}
  <div class="chart-card">
    <h3>Category Distribution</h3>
    <div class="chart-wrapper">
      <canvas id="categoryChart"></canvas>
    </div>
  </div>
  {% endif %}

  <div class="chart-card">
    <h3>Risk Gauge</h3>
    <div class="risk-gauge">
      <div class="risk-circle {{ 'low' if chart_data.risk_score < 40 else ('medium' if chart_data.risk_score < 70 else ('high' if chart_data.risk_score < 85 else 'critical')) }}">
        {{ chart_data.risk_score }}
      </div>
      <div class="risk-label">
        {{ 'Low' if chart_data.risk_score < 40 else ('Medium' if chart_data.risk_score < 70 else ('High' if chart_data.risk_score < 85 else 'Critical')) }}
      </div>
    </div>
  </div>

  {% if chart_data.timeline %}
  <div class="chart-card">
    <h3>Findings Timeline</h3>
    <div class="chart-wrapper">
      <canvas id="timelineChart"></canvas>
    </div>
  </div>
  {% endif %}
</div>
{% endif %}

<!-- Modules -->
{% for name, module in modules.items() %}
<div class="module-section">
  <div class="module-header" onclick="toggleModule(this)">
    <h2>{{ name|upper }} ({{ module.sources|length }} sources)</h2>
    <span class="module-toggle">›</span>
  </div>
  <div class="module-body">
    {% for key, value in module.data.items() %}
      {% if key != 'timestamp' %}
      <div class="data-row">
        <div class="data-key">{{ key|replace('_', ' ') }}</div>
        <div class="data-value">
          {% if value is boolean %}
            {% if value %}<span class="badge success">Yes</span>{% else %}<span class="badge danger">No</span>{% endif %}
          {% elif value is string %}
            {% if value.startswith('http') %}<a href="{{ value }}" target="_blank">{{ value }}</a>{% else %}{{ value }}{% endif %}
          {% elif value is mapping %}
            <ul>
              {% for k, v in value.items() %}
              <li><strong>{{ k }}:</strong> {{ v }}</li>
              {% endfor %}
            </ul>
          {% elif value is sequence and value %}
            {% if value[0] is mapping %}
              <ul>
                {% for item in value[:20] %}
                <li>
                  {% for k, v in item.items() %}
                    {% if v is string and v.startswith('http') %}<a href="{{ v }}" target="_blank">{{ k }}</a>{% else %}<strong>{{ k }}:</strong> {{ v }}{% endif %}
                    {% if not loop.last %} &middot; {% endif %}
                  {% endfor %}
                </li>
                {% endfor %}
                {% if value|length > 20 %}<li><em>... and {{ value|length - 20 }} more</em></li>{% endif %}
              </ul>
            {% else %}
              {% for v in value[:30] %}<span class="badge info">{{ v }}</span> {% endfor %}
              {% if value|length > 30 %}<em>... +{{ value|length - 30 }} more</em>{% endif %}
            {% endif %}
          {% else %}
            {{ value }}
          {% endif %}
        </div>
      </div>
      {% endif %}
    {% endfor %}

    {% if module.sources %}
    <div class="data-row">
      <div class="data-key">Sources</div>
      <div class="data-value">
        {% for s in module.sources %}<span class="badge info">{{ s }}</span> {% endfor %}
      </div>
    </div>
    {% endif %}
  </div>
</div>
{% endfor %}

<!-- Correlation -->
{% if correlation and correlation.entities %}
<div class="module-section open">
  <div class="module-header" onclick="toggleModule(this)">
    <h2>Correlation</h2>
    <span class="module-toggle">›</span>
  </div>
  <div class="module-body">
    <div class="data-row">
      <div class="data-key">Primary Target</div>
      <div class="data-value">{{ correlation.primary }}</div>
    </div>
    {% for etype, entities in correlation.entities.items() %}
      {% if entities %}
      <div class="data-row">
        <div class="data-key">{{ etype|upper }} ({{ entities|length }})</div>
        <div class="data-value">
          {% for e in entities[:15] %}<span class="badge info">{{ e }}</span> {% endfor %}
          {% if entities|length > 15 %}<em>... +{{ entities|length - 15 }} more</em>{% endif %}
        </div>
      </div>
      {% endif %}
    {% endfor %}
  </div>
</div>
{% endif %}

<!-- Footer -->
<div class="report-footer">
  Generated by <strong>GhostIntel v{{ version }}</strong> &middot;
  <a href="https://github.com/ruyynn" target="_blank">GitHub</a> &middot;
  <a href="https://saweria.co/Ruyynn" target="_blank">Support</a>
  <br>
  <em>For educational and authorized security research only.</em>
</div>

</div>

<script>
// Theme toggle
function toggleTheme() {
  document.body.classList.toggle('light-theme');
  try { localStorage.setItem('gi-theme', document.body.className); } catch(e) {}
}

(function() {
  try {
    var saved = localStorage.getItem('gi-theme');
    if (saved === 'light-theme') document.body.classList.add('light-theme');
  } catch(e) {}
})();

// Module toggle
function toggleModule(header) {
  header.parentElement.classList.toggle('open');
}

// Charts
document.addEventListener('DOMContentLoaded', function() {
  var chartData = {{ chart_data|tojson|safe if chart_data else '{}' }};

  if (typeof Chart === 'undefined') {
    // Load Chart.js dynamically
    var s = document.createElement('script');
    s.src = '{{ chart_cdn }}';
    s.onload = initCharts;
    document.head.appendChild(s);
  } else {
    initCharts();
  }

  function initCharts() {
    if (typeof Chart === 'undefined') return;

    // Category distribution
    var catEl = document.getElementById('categoryChart');
    if (catEl && chartData.category_distribution) {
      var labels = Object.keys(chartData.category_distribution);
      var data = labels.map(function(k){ return chartData.category_distribution[k]; });
      new Chart(catEl, {
        type: 'doughnut',
        data: {
          labels: labels,
          datasets: [{
            data: data,
            backgroundColor: ['#2dd4bf','#10b981','#f59e0b','#f97316','#ef4444','#a78bfa','#3b82f6','#ec4899']
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position:'bottom', labels:{ color: getTextColor() } }
          }
        }
      });
    }

    // Timeline (platform findings by category)
    var tlEl = document.getElementById('timelineChart');
    if (tlEl && chartData.timeline && chartData.timeline.length) {
      var catMap = {};
      chartData.timeline.forEach(function(t) {
        catMap[t.category] = (catMap[t.category]||0) + 1;
      });
      var labels = Object.keys(catMap);
      var counts = labels.map(function(k){ return catMap[k]; });
      new Chart(tlEl, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Findings',
            data: counts,
            backgroundColor: '#2dd4bf'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: getTextColor() }, grid: { color: getGridColor() } },
            y: { ticks: { color: getTextColor() }, grid: { color: getGridColor() }, beginAtZero: true }
          }
        }
      });
    }
  }

  function getTextColor() {
    return document.body.classList.contains('light-theme') ? '#111827' : '#e6e9ef';
  }
  function getGridColor() {
    return document.body.classList.contains('light-theme') ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)';
  }
});
</script>
</body>
</html>
"""
