#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Web Server

Clean localhost dashboard — runs the engine in background threads.
"""

import asyncio
import json
import threading
import webbrowser
import time
import sys
from pathlib import Path
from datetime import datetime

from flask import Flask, request, jsonify, Response

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.engine import GhostIntelEngine
from core.detector import detector
from core.banner import VERSION, AUTHOR, GITHUB, SAWERIA
from core.config import get_config

app = Flask(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  WEB UI  (single HTML page, minimal CDN, dark by default)
# ─────────────────────────────────────────────────────────────────────────────
HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>GhostIntel v""" + VERSION + r"""</title>
<style>
:root{
  --bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--bg4:#1c2128;
  --border:#21262d;--border2:#30363d;
  --cyan:#22d3ee;--cyan2:#06b6d4;
  --green:#4ade80;--yellow:#fbbf24;--red:#f87171;--purple:#a78bfa;--orange:#fb923c;
  --text:#e6edf3;--text2:#8b949e;--text3:#6e7681;
  --magenta:#d946ef;
}
.light{
  --bg:#f6f8fa;--bg2:#ffffff;--bg3:#f0f3f7;--bg4:#e1e7ed;
  --border:#d0d7de;--border2:#afb8c1;
  --text:#1f2328;--text2:#59636e;--text3:#6e7781;
}
*{box-sizing:border-box;margin:0;padding:0}
html{height:100%}
body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;height:100vh;display:flex;flex-direction:column;overflow:hidden;font-size:14px}

header{background:var(--bg2);border-bottom:1px solid var(--border);padding:0 1rem;height:52px;display:flex;align-items:center;gap:1rem;flex-shrink:0}
header .logo{font-weight:700;color:var(--cyan);letter-spacing:0.05em;font-size:1.1rem}
header .logo span{color:var(--text)}
header .version{color:var(--text3);font-size:0.75rem;border:1px solid var(--border2);padding:0.125rem 0.5rem;border-radius:4px}
header .spacer{flex:1}
header .links{display:flex;gap:0.75rem;align-items:center}
header .links a{color:var(--text2);text-decoration:none;font-size:0.85rem;transition:color 0.15s}
header .links a:hover{color:var(--cyan)}
header button{background:var(--bg3);color:var(--text);border:1px solid var(--border2);border-radius:6px;padding:0.4rem 0.75rem;cursor:pointer;font-size:0.85rem}
header button:hover{background:var(--bg4)}

main{flex:1;display:flex;overflow:hidden}

/* Sidebar */
.sidebar{width:280px;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0}
.sidebar .input-area{padding:1rem;border-bottom:1px solid var(--border)}
.sidebar .input-area label{display:block;color:var(--text2);font-size:0.75rem;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.5rem}
.sidebar textarea{width:100%;background:var(--bg);color:var(--text);border:1px solid var(--border2);border-radius:6px;padding:0.5rem;font-family:inherit;font-size:0.875rem;resize:vertical;min-height:60px}
.sidebar textarea:focus{outline:none;border-color:var(--cyan)}
.sidebar .detected{margin-top:0.5rem;font-size:0.75rem;color:var(--text3)}
.sidebar .detected .type{color:var(--green);font-weight:600}

.sidebar .options{padding:1rem;border-bottom:1px solid var(--border);overflow-y:auto;flex:1}
.sidebar .options .opt{margin-bottom:0.75rem}
.sidebar .options .opt label{display:flex;align-items:center;gap:0.5rem;font-size:0.85rem;color:var(--text2);cursor:pointer}
.sidebar .options .opt input[type=checkbox]{accent-color:var(--cyan)}
.sidebar .options .opt select{background:var(--bg);color:var(--text);border:1px solid var(--border2);border-radius:4px;padding:0.25rem;font-size:0.8rem;width:100%;margin-top:0.25rem}

.sidebar .actions{padding:1rem;border-top:1px solid var(--border)}
.sidebar .btn-run{width:100%;background:var(--cyan);color:var(--bg);border:none;border-radius:6px;padding:0.65rem;cursor:pointer;font-weight:600;font-size:0.9rem;transition:background 0.15s}
.sidebar .btn-run:hover{background:var(--cyan2)}
.sidebar .btn-run:disabled{background:var(--bg4);color:var(--text3);cursor:not-allowed}

/* History */
.history{padding:0.5rem;max-height:200px;overflow-y:auto;border-top:1px solid var(--border)}
.history .item{padding:0.5rem;border-radius:4px;cursor:pointer;font-size:0.8rem;color:var(--text2);display:flex;justify-content:space-between;align-items:center}
.history .item:hover{background:var(--bg3)}
.history .item .t{color:var(--text3);font-size:0.7rem}

/* Content area */
.content{flex:1;overflow-y:auto;padding:1.5rem}
.content .empty{text-align:center;color:var(--text3);margin-top:5rem}
.content .empty h2{color:var(--text2);font-size:1.25rem;margin-bottom:0.5rem}
.content .empty p{font-size:0.875rem;max-width:400px;margin:0 auto;line-height:1.5}

/* Result cards */
.result-card{background:var(--bg2);border:1px solid var(--border);border-radius:8px;margin-bottom:1rem;overflow:hidden}
.result-card .card-header{background:var(--bg3);padding:0.75rem 1rem;display:flex;justify-content:space-between;align-items:center;cursor:pointer;border-bottom:1px solid var(--border)}
.result-card .card-header h3{color:var(--cyan);font-size:0.875rem;text-transform:uppercase;letter-spacing:0.05em}
.result-card .card-header .count{color:var(--text3);font-size:0.75rem}
.result-card .card-body{padding:1rem;display:none}
.result-card.open .card-body{display:block}

.result-card .row{display:grid;grid-template-columns:180px 1fr;gap:1rem;padding:0.5rem 0;border-bottom:1px solid var(--border)}
.result-card .row:last-child{border-bottom:none}
.result-card .row .k{color:var(--text2);font-size:0.8rem;text-transform:capitalize}
.result-card .row .v{color:var(--text);word-break:break-word;font-size:0.875rem}
.result-card .row .v a{color:var(--cyan);text-decoration:none}
.result-card .row .v a:hover{text-decoration:underline}

.badge{display:inline-block;padding:0.125rem 0.5rem;border-radius:4px;font-size:0.7rem;font-weight:600;margin-right:0.25rem;margin-bottom:0.25rem}
.badge.green{background:rgba(74,222,128,0.15);color:var(--green)}
.badge.yellow{background:rgba(251,191,36,0.15);color:var(--yellow)}
.badge.red{background:rgba(248,113,113,0.15);color:var(--red)}
.badge.cyan{background:rgba(34,211,238,0.15);color:var(--cyan)}
.badge.purple{background:rgba(167,139,250,0.15);color:var(--purple)}

/* Loading */
.loading{display:flex;align-items:center;justify-content:center;padding:3rem;color:var(--text2)}
.loading .spinner{display:inline-block;width:24px;height:24px;border:2px solid var(--border2);border-top-color:var(--cyan);border-radius:50%;animation:spin 0.8s linear infinite;margin-right:0.75rem}
@keyframes spin{to{transform:rotate(360deg)}}

/* Progress */
.progress-bar{background:var(--bg3);border-radius:4px;height:6px;overflow:hidden;margin:0.5rem 0}
.progress-bar .fill{background:var(--cyan);height:100%;transition:width 0.3s;width:0%}

/* Footer */
footer{background:var(--bg2);border-top:1px solid var(--border);padding:0.5rem 1rem;text-align:center;color:var(--text3);font-size:0.75rem;flex-shrink:0}
footer a{color:var(--cyan);text-decoration:none}

@media (max-width:768px){
  .sidebar{width:100%;height:auto;max-height:50vh}
  main{flex-direction:column}
}
</style>
</head>
<body>

<header>
  <div class="logo">GHOST<span>INTEL</span></div>
  <span class="version">v""" + VERSION + r"""</span>
  <div class="spacer"></div>
  <div class="links">
    <a href="""" + GITHUB + r"""" target="_blank">GitHub</a>
    <a href="""" + SAWERIA + r"""" target="_blank">Support</a>
    <button onclick="toggleTheme()">Theme</button>
  </div>
</header>

<main>
  <aside class="sidebar">
    <div class="input-area">
      <label>Target</label>
      <textarea id="target" placeholder="username, email, phone, domain, or IP"></textarea>
      <div class="detected">Type: <span class="type" id="detected-type">—</span></div>
    </div>

    <div class="options">
      <div class="opt">
        <label><input type="checkbox" id="deep" checked> Deep investigation</label>
      </div>
      <div class="opt">
        <label><input type="checkbox" id="scrape"> Scrape profile data</label>
      </div>
      <div class="opt">
        <label>Output format</label>
        <select id="format">
          <option value="json">JSON</option>
          <option value="html" selected>HTML</option>
          <option value="txt">TXT</option>
          <option value="md">Markdown</option>
          <option value="all">All formats</option>
        </select>
      </div>
      <div class="opt">
        <label>Language</label>
        <select id="lang">
          <option value="en">English</option>
          <option value="id">Bahasa Indonesia</option>
        </select>
      </div>
    </div>

    <div class="actions">
      <button class="btn-run" id="btnRun" onclick="runScan()">Run scan</button>
    </div>

    <div class="history" id="history">
      <!-- History items here -->
    </div>
  </aside>

  <section class="content" id="content">
    <div class="empty">
      <h2>GhostIntel Dashboard</h2>
      <p>Enter a target on the left (username, email, phone, domain, or IP) and hit <strong>Run scan</strong>. All processing happens locally — your target never leaves this machine except for the public OSINT sources queried.</p>
    </div>
  </section>
</main>

<footer>
  GhostIntel v""" + VERSION + r""" &middot; <a href="""" + GITHUB + r"""" target="_blank">GitHub</a> &middot;
  Educational use only &middot; <a href="""" + SAWERIA + r"""" target="_blank">Support</a>
</footer>

<script>
// Theme
function toggleTheme(){document.body.classList.toggle('light');try{localStorage.setItem('gi-theme',document.body.className)}catch(e){}}
(function(){try{var s=localStorage.getItem('gi-theme');if(s)document.body.className=s}catch(e){}})();

// Detect type
document.getElementById('target').addEventListener('input',function(){
  var v=this.value.trim();
  var t='—';
  if(/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(v))t='email';
  else if(/^\\+?\\d[\\d\\s\\-\\(\\)]{6,}$/.test(v))t='phone';
  else if(/^\\d{1,3}(\\.\\d{1,3}){3}$/.test(v))t='ip';
  else if(/^([a-z0-9\\-]+\\.)+[a-z]{2,}$/i.test(v))t='domain';
  else if(v)t='username';
  document.getElementById('detected-type').textContent=t;
});

// History
function loadHistory(){
  try{
    var h=JSON.parse(localStorage.getItem('gi-history')||'[]');
    var el=document.getElementById('history');
    el.innerHTML='<div style="padding:0.5rem;font-size:0.7rem;color:var(--text3);text-transform:uppercase">Recent</div>';
    h.slice(0,8).forEach(function(item){
      var d=document.createElement('div');
      d.className='item';
      d.innerHTML='<span>'+item.target+'</span><span class="t">'+item.time+'</span>';
      d.onclick=function(){document.getElementById('target').value=item.target;document.getElementById('detected-type').textContent=item.type};
      el.appendChild(d);
    });
  }catch(e){}
}
function saveHistory(target,type){
  try{
    var h=JSON.parse(localStorage.getItem('gi-history')||'[]');
    h.unshift({target:target,type:type,time:new Date().toLocaleTimeString()});
    h=h.slice(0,20);
    localStorage.setItem('gi-history',JSON.stringify(h));
    loadHistory();
  }catch(e){}
}
loadHistory();

// Run scan
function runScan(){
  var target=document.getElementById('target').value.trim();
  if(!target){alert('Enter a target first');return}
  var btn=document.getElementById('btnRun');
  btn.disabled=true;btn.textContent='Scanning...';

  var content=document.getElementById('content');
  content.innerHTML='<div class="loading"><div class="spinner"></div>Scanning <strong>'+target+'</strong>...</div>';

  var data={
    target:target,
    deep:document.getElementById('deep').checked,
    scrape:document.getElementById('scrape').checked,
    format:document.getElementById('format').value,
    lang:document.getElementById('lang').value
  };

  fetch('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})
    .then(function(r){return r.json()})
    .then(function(data){
      btn.disabled=false;btn.textContent='Run scan';
      if(data.error){content.innerHTML='<div class="loading">'+data.error+'</div>';return}
      saveHistory(target,data.target_type||'auto');
      renderResults(data);
    })
    .catch(function(err){
      btn.disabled=false;btn.textContent='Run scan';
      content.innerHTML='<div class="loading">Error: '+err.message+'</div>';
    });
}

function renderResults(data){
  var content=document.getElementById('content');
  var html='<div style="margin-bottom:1rem;color:var(--text2);font-size:0.875rem">Target: <strong style="color:var(--cyan)">'+data.target+'</strong> &middot; '+data.timestamp+'</div>';

  if(data.results){
    Object.keys(data.results).forEach(function(name){
      if(name.startsWith('_'))return;
      var mod=data.results[name];
      if(!mod||!mod.data)return;
      html+='<div class="result-card">';
      html+='<div class="card-header" onclick="this.parentElement.classList.toggle(\'open\')"><h3>'+name.toUpperCase()+'</h3><span class="count">'+(mod.sources?mod.sources.length:0)+' sources</span></div>';
      html+='<div class="card-body">';
      Object.keys(mod.data).forEach(function(k){
        if(k==='timestamp')return;
        var v=mod.data[k];
        var valHtml=formatValue(v);
        html+='<div class="row"><div class="k">'+k.replace(/_/g,' ')+'</div><div class="v">'+valHtml+'</div></div>';
      });
      if(mod.sources&&mod.sources.length){
        html+='<div class="row"><div class="k">sources</div><div class="v">'+mod.sources.map(function(s){return '<span class="badge cyan">'+s+'</span>'}).join('')+'</div></div>';
      }
      html+='</div></div>';
    });
  }

  if(data.correlation&&data.correlation.entities){
    html+='<div class="result-card open"><div class="card-header" onclick="this.parentElement.classList.toggle(\'open\')"><h3>Correlation</h3><span class="count">primary: '+data.correlation.primary+'</span></div><div class="card-body">';
    Object.keys(data.correlation.entities).forEach(function(etype){
      var ents=data.correlation.entities[etype];
      if(ents&&ents.length){
        html+='<div class="row"><div class="k">'+etype.toUpperCase()+' ('+ents.length+')</div><div class="v">'+ents.slice(0,20).map(function(e){return '<span class="badge purple">'+e+'</span>'}).join('')+'</div></div>';
      }
    });
    html+='</div></div>';
  }

  content.innerHTML=html;
}

function formatValue(v){
  if(v===null||v===undefined)return '<span style="color:var(--text3)">—</span>';
  if(typeof v==='boolean')return v?'<span class="badge green">Yes</span>':'<span class="badge red">No</span>';
  if(typeof v==='string'){
    if(v.startsWith('http'))return '<a href="'+v+'" target="_blank">'+v+'</a>';
    return v;
  }
  if(typeof v==='number')return String(v);
  if(Array.isArray(v)){
    if(v.length===0)return '<span style="color:var(--text3)">empty</span>';
    if(typeof v[0]==='object'){
      return '<ul style="list-style:none;padding:0">'+v.slice(0,20).map(function(item){
        var s=Object.keys(item).slice(0,4).map(function(k){
          var iv=item[k];
          if(typeof iv==='string'&&iv.startsWith('http'))return '<a href="'+iv+'" target="_blank">'+k+'</a>';
          return '<strong>'+k+':</strong> '+iv;
        }).join(' &middot; ');
        return '<li style="padding:0.25rem 0;border-bottom:1px solid var(--border)">'+s+'</li>';
      }).join('')+(v.length>20?'<li style="padding:0.25rem 0;color:var(--text3)">... +'+(v.length-20)+' more</li>':'')+'</ul>';
    }
    return v.slice(0,30).map(function(x){return '<span class="badge cyan">'+x+'</span>'}).join('')+(v.length>30?' <span style="color:var(--text3)">+'+(v.length-30)+'</span>':'');
  }
  if(typeof v==='object'){
    return '<ul style="list-style:none;padding:0">'+Object.keys(v).slice(0,15).map(function(k){return '<li><strong>'+k+':</strong> '+formatValue(v[k])+'</li>'}).join('')+'</ul>';
  }
  return String(v);
}
</script>
</body>
</html>
"""


def _run_async_scan(target: str, deep: bool, scrape: bool, lang: str):
    """Run an async scan in its own event loop (called from a thread)."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        async def _do():
            engine = GhostIntelEngine(timeout=15, max_concurrent=20,
                                       scrape=scrape, lang=lang)
            async with engine:
                if deep:
                    results = await engine.investigate_all(target, "auto")
                else:
                    r = await engine.investigate(target, "auto")
                    results = {r.get("module", "result"): r} if r and not r.get("error") else {}
                # Make serializable
                from reports.generator import ReportGenerator
                rg = ReportGenerator()
                return rg._make_serializable(results), engine.results
            return None, None
        return loop.run_until_complete(_do())
    finally:
        loop.close()


@app.route("/")
def index():
    return Response(HTML, mimetype="text/html")


@app.route("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "version": VERSION,
        "author": AUTHOR,
        "time": datetime.now().isoformat(),
    })


@app.route("/api/scan", methods=["POST"])
def scan():
    data = request.get_json(force=True, silent=True) or {}
    target = (data.get("target") or "").strip()
    if not target:
        return jsonify({"error": "No target provided"}), 400

    deep = bool(data.get("deep", True))
    scrape = bool(data.get("scrape", False))
    lang = data.get("lang", "en")

    # Detect type for response
    entity = detector.detect(target)
    target_type = entity.type
    target_norm = entity.normalized

    try:
        results, raw = _run_async_scan(target_norm, deep, scrape, lang)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    if not results:
        return jsonify({
            "target": target,
            "target_type": target_type,
            "timestamp": datetime.now().isoformat(),
            "results": {},
            "message": "No results found"
        })

    # Pull correlation if available
    correlation = results.get("_correlation", {}) if isinstance(results, dict) else {}

    return jsonify({
        "target": target,
        "target_type": target_type,
        "timestamp": datetime.now().isoformat(),
        "results": results,
        "correlation": correlation,
    })


@app.route("/api/detect", methods=["POST"])
def detect():
    data = request.get_json(force=True, silent=True) or {}
    target = (data.get("target") or "").strip()
    if not target:
        return jsonify({"error": "No target"}), 400
    entity = detector.detect(target)
    return jsonify({
        "type": entity.type,
        "normalized": entity.normalized,
        "confidence": entity.confidence,
        "country": entity.country,
    })


def start_web_server(port: int = 7331, open_browser: bool = True):
    """Start the Flask web server."""
    from core.banner import console
    console.print(f"\n[cyan]Web UI starting on [bold]http://localhost:{port}[/bold][/cyan]")
    console.print(f"[dim]Press Ctrl+C to stop[/dim]\n")

    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(f"http://localhost:{port}")).start()

    try:
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        console.print("\n[yellow]! Stopped[/yellow]")
    except Exception as e:
        console.print(f"[red]✗ Server error: {e}[/red]")
