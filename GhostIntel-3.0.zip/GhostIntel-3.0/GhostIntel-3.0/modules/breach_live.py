#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Real-time breach check (HaveIBeenPwned + local DB)"""

import asyncio
import hashlib
from datetime import datetime
from typing import Dict, List, Optional
import aiohttp

from modules.base import BaseModule
from core.secrets import secrets
from sources.breach_db import BreachDB


class BreachLiveModule(BaseModule):
    """Real-time breach check.

    Uses HIBP API when an API key is provided (recommended), otherwise falls
    back to a local public-breach database.
    """

    HIBP_BREACHES = "https://haveibeenpwned.com/api/v3/breachedaccount/{}?truncateResponse=false"
    HIBP_PASTES = "https://haveibeenpwned.com/api/v3/pasteaccount/{}"

    def __init__(self, session):
        super().__init__(session)
        self.name = "breach_live"
        self.local_db = BreachDB()

    async def scan(self, email: str) -> Dict:
        email = email.lower().strip()
        if "@" not in email:
            return self.error_result(email, "Invalid email format")

        hibp_breaches, hibp_pastes, local_breaches = await asyncio.gather(
            self._hibp_breaches(email),
            self._hibp_pastes(email),
            self._local_breaches(email),
        )

        all_breaches: List[Dict] = []
        if hibp_breaches:
            all_breaches.extend(hibp_breaches)
        if local_breaches:
            all_breaches.extend(local_breaches)

        # Deduplicate by breach name
        seen = set()
        deduped = []
        for b in all_breaches:
            name = b.get("Name") or b.get("name")
            if name and name not in seen:
                seen.add(name)
                deduped.append(b)

        deduped.sort(
            key=lambda x: x.get("BreachDate") or x.get("year", ""),
            reverse=True,
        )

        risk = self._calc_risk(deduped)

        result = {
            "email": email,
            "hibp_available": secrets.has_api_key("hibp"),
            "hibp_breaches_count": len(hibp_breaches) if hibp_breaches else 0,
            "hibp_pastes_count": len(hibp_pastes) if hibp_pastes else 0,
            "local_breaches_count": len(local_breaches) if local_breaches else 0,
            "total_breaches": len(deduped),
            "breaches": deduped,
            "pastes": hibp_pastes or [],
            "risk_score": risk,
            "risk_level": self._risk_level(risk),
            "recommendation": self._recommendation(risk),
            "timestamp": datetime.now().isoformat(),
        }

        sources = []
        if hibp_breaches:
            sources.append("hibp")
        if hibp_pastes:
            sources.append("hibp_pastes")
        if local_breaches:
            sources.append("local_db")
        return self.create_result(email, result, sources)

    async def _hibp_breaches(self, email: str) -> Optional[List[Dict]]:
        api_key = secrets.get_api_key("hibp")
        if not api_key:
            return None
        try:
            async with self.session.get(
                self.HIBP_BREACHES.format(email),
                headers={
                    "hibp-api-key": api_key,
                    "User-Agent": "GhostIntel-OSINT",
                },
                timeout=aiohttp.ClientTimeout(total=10),
            ) as r:
                if r.status == 404:
                    return []
                if r.status != 200:
                    return None
                data = await r.json()
                return data if isinstance(data, list) else []
        except Exception:
            return None

    async def _hibp_pastes(self, email: str) -> Optional[List[Dict]]:
        api_key = secrets.get_api_key("hibp")
        if not api_key:
            return None
        try:
            async with self.session.get(
                self.HIBP_PASTES.format(email),
                headers={
                    "hibp-api-key": api_key,
                    "User-Agent": "GhostIntel-OSINT",
                },
                timeout=aiohttp.ClientTimeout(total=10),
            ) as r:
                if r.status == 404:
                    return []
                if r.status != 200:
                    return None
                data = await r.json()
                return data if isinstance(data, list) else []
        except Exception:
            return None

    async def _local_breaches(self, email: str) -> List[Dict]:
        domain = email.split("@")[-1]
        results = self.local_db.search_by_domain(domain)
        # Also try domain alias
        aliases = {
            "gmail.com": "Google",
            "yahoo.com": "Yahoo",
            "hotmail.com": "Microsoft",
            "outlook.com": "Microsoft",
        }
        alias = aliases.get(domain)
        if alias:
            results = results + self.local_db.search_by_domain(alias)
        # Dedup
        seen = set()
        out = []
        for b in results:
            if b["name"] not in seen:
                seen.add(b["name"])
                out.append({
                    "Name": b["name"],
                    "BreachDate": str(b.get("year", "")),
                    "PwnCount": b.get("records", 0),
                    "DataClasses": b.get("data_types", []),
                    "Description": b.get("description", ""),
                    "source": "local_db",
                })
        return out

    def _calc_risk(self, breaches: List[Dict]) -> int:
        if not breaches:
            return 0
        score = 0
        # Recency
        now_year = datetime.now().year
        for b in breaches[:10]:
            bd = b.get("BreachDate") or b.get("year", "")
            try:
                year = int(str(bd)[:4])
                if year >= now_year - 1:
                    score += 15
                elif year >= now_year - 3:
                    score += 10
                else:
                    score += 5
            except Exception:
                pass
            # Severity by data types
            dt = b.get("DataClasses") or b.get("data_types") or []
            if "passwords" in dt:
                score += 8
            if "credit_cards" in dt or "credit card numbers" in dt:
                score += 10
            if "phone_numbers" in dt:
                score += 3
        return min(score, 100)

    def _risk_level(self, score: int) -> str:
        if score >= 70:
            return "critical"
        if score >= 50:
            return "high"
        if score >= 30:
            return "medium"
        if score >= 10:
            return "low"
        return "minimal"

    def _recommendation(self, score: int) -> str:
        if score >= 70:
            return "Change all passwords immediately. Enable 2FA. Watch for phishing emails."
        if score >= 50:
            return "Change passwords for affected services. Enable 2FA where available."
        if score >= 30:
            return "Update passwords if you haven't recently. Use a password manager."
        if score >= 10:
            return "Minor exposure — keep passwords unique and rotated."
        return "No major exposure detected. Maintain good password hygiene."


async def check_password_breach(password: str, session: aiohttp.ClientSession) -> Dict:
    """k-anonymity HIBP password check (no API key needed)."""
    sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
    prefix, suffix = sha1[:5], sha1[5:]
    url = f"https://api.pwnedpasswords.com/range/{prefix}"
    try:
        async with session.get(
            url, timeout=aiohttp.ClientTimeout(total=10)
        ) as r:
            if r.status != 200:
                return {"error": f"HTTP {r.status}"}
            text = await r.text()
            for line in text.splitlines():
                if ":" in line:
                    s, count = line.split(":", 1)
                    if s == suffix:
                        return {
                            "breached": True,
                            "count": int(count),
                            "hash": sha1,
                        }
            return {"breached": False, "count": 0, "hash": sha1}
    except Exception as e:
        return {"error": str(e)}
