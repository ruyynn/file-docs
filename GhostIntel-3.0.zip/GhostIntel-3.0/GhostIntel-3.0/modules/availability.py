#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Username Availability checker

Check whether a username is *available* (not yet registered) on each platform.
Inverse of the username existence check — useful for brand/identity research.
"""

import asyncio
import random
from datetime import datetime
from typing import Dict, Optional
import aiohttp

from modules.base import BaseModule
from sources.social_media import SocialMediaDB


class AvailabilityModule(BaseModule):
    """Check username availability across platforms."""

    def __init__(self, session):
        super().__init__(session)
        self.name = "availability"
        self.social_db = SocialMediaDB()

        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        ]

    async def scan(self, username: str) -> Dict:
        username = username.strip().lstrip("@")
        if not username:
            return self.error_result(username, "Empty username")

        platforms = self.social_db.get_all_platforms()
        available = []
        taken = []
        unknown = []

        semaphore = asyncio.Semaphore(15)

        async def check_one(platform: Dict):
            async with semaphore:
                url = platform["url"].format(username)
                headers = {
                    "User-Agent": random.choice(self.user_agents),
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.9",
                }
                try:
                    async with self.session.get(
                        url,
                        headers=headers,
                        timeout=aiohttp.ClientTimeout(total=8),
                        allow_redirects=True,
                        ssl=False,
                    ) as resp:
                        if resp.status == 404:
                            available.append({
                                "platform": platform["name"],
                                "url": url,
                                "category": platform.get("category", "social"),
                            })
                        elif resp.status == 200:
                            text = await resp.text(errors="ignore", limit=50000)
                            low = text.lower()[:5000]
                            if any(s in low for s in (
                                "user not found", "page not found",
                                "doesn't exist", "profile not found",
                                "account doesn't exist",
                            )):
                                available.append({
                                    "platform": platform["name"],
                                    "url": url,
                                    "category": platform.get("category", "social"),
                                })
                            else:
                                taken.append({
                                    "platform": platform["name"],
                                    "url": str(resp.url),
                                    "category": platform.get("category", "social"),
                                })
                        else:
                            unknown.append({
                                "platform": platform["name"],
                                "status": resp.status,
                            })
                except (asyncio.TimeoutError, aiohttp.ClientError):
                    unknown.append({
                        "platform": platform["name"],
                        "status": "timeout",
                    })
                except Exception:
                    unknown.append({
                        "platform": platform["name"],
                        "status": "error",
                    })

        # Run in batches
        batch_size = 15
        for i in range(0, len(platforms), batch_size):
            batch = platforms[i:i + batch_size]
            await asyncio.gather(*(check_one(p) for p in batch))
            await asyncio.sleep(random.uniform(0.2, 0.5))

        total = len(platforms)
        result = {
            "username": username,
            "total_checked": total,
            "available_count": len(available),
            "taken_count": len(taken),
            "unknown_count": len(unknown),
            "availability_rate": round((len(available) / total) * 100, 2) if total else 0,
            "available": available,
            "taken": taken[:50],
            "unknown_count_detail": len(unknown),
            "timestamp": datetime.now().isoformat(),
        }

        sources = ["http_status"]
        return self.create_result(username, result, sources)
