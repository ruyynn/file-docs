#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Phone Module (10 countries + multi-format output)"""

import re
import phonenumbers
from phonenumbers import carrier, geocoder, timezone as pn_tz
from typing import Dict, List, Optional
from datetime import datetime
from modules.base import BaseModule
from sources.phone_db import PhoneProviderDB


# Extended country info database (10 countries + useful extras)
COUNTRY_INFO = {
    'ID': {'name': 'Indonesia', 'whatsapp_prefix': '62', 'telegram_prefix': '62',
           'flag': 'ID', 'currency': 'IDR', 'continent': 'Asia'},
    'US': {'name': 'United States', 'whatsapp_prefix': '1', 'telegram_prefix': '1',
           'flag': 'US', 'currency': 'USD', 'continent': 'North America'},
    'GB': {'name': 'United Kingdom', 'whatsapp_prefix': '44', 'telegram_prefix': '44',
           'flag': 'UK', 'currency': 'GBP', 'continent': 'Europe'},
    'MY': {'name': 'Malaysia', 'whatsapp_prefix': '60', 'telegram_prefix': '60',
           'flag': 'MY', 'currency': 'MYR', 'continent': 'Asia'},
    'IN': {'name': 'India', 'whatsapp_prefix': '91', 'telegram_prefix': '91',
           'flag': 'IN', 'currency': 'INR', 'continent': 'Asia'},
    'AU': {'name': 'Australia', 'whatsapp_prefix': '61', 'telegram_prefix': '61',
           'flag': 'AU', 'currency': 'AUD', 'continent': 'Oceania'},
    'SG': {'name': 'Singapore', 'whatsapp_prefix': '65', 'telegram_prefix': '65',
           'flag': 'SG', 'currency': 'SGD', 'continent': 'Asia'},
    'PH': {'name': 'Philippines', 'whatsapp_prefix': '63', 'telegram_prefix': '63',
           'flag': 'PH', 'currency': 'PHP', 'continent': 'Asia'},
    'TH': {'name': 'Thailand', 'whatsapp_prefix': '66', 'telegram_prefix': '66',
           'flag': 'TH', 'currency': 'THB', 'continent': 'Asia'},
    'VN': {'name': 'Vietnam', 'whatsapp_prefix': '84', 'telegram_prefix': '84',
           'flag': 'VN', 'currency': 'VND', 'continent': 'Asia'},
}


class PhoneModule(BaseModule):
    def __init__(self, session):
        super().__init__(session)
        self.name = "phone"
        self.provider_db = PhoneProviderDB()

        self.supported_countries = list(COUNTRY_INFO.keys())

    async def scan(self, phone: str) -> Dict:
        try:
            phone = phone.strip()
            parsed = None
            detected_country = None

            for country in self.supported_countries:
                try:
                    p = phonenumbers.parse(phone, country)
                    if phonenumbers.is_possible_number(p):
                        parsed = p
                        detected_country = country
                        break
                except Exception:
                    continue

            if not parsed:
                try:
                    parsed = phonenumbers.parse(phone, None)
                except Exception:
                    return self.error_result(phone, "Invalid phone number format")

            if not phonenumbers.is_valid_number(parsed):
                return self.error_result(phone, "Not a valid phone number")

            national = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)
            international = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
            e164 = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
            rfc3966 = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.RFC3966)

            country_iso = phonenumbers.region_code_for_number(parsed) or detected_country
            country_name = geocoder.description_for_number(parsed, "en") or "Unknown"
            location = geocoder.description_for_number(parsed, "en")
            if location == country_name:
                location = None

            prov = carrier.name_for_number(parsed, "en")
            if not prov and country_iso:
                clean_number = e164.lstrip("+")
                prov = self.provider_db.get_provider(clean_number, country_iso)

            if prov:
                prov = prov.replace("Mobile", "").strip()
                prov = prov.replace("Pvt Ltd", "").strip()

            num_type = phonenumbers.number_type(parsed)
            type_map = {
                0: "Fixed Line",
                1: "Mobile",
                2: "Fixed/Mobile",
                3: "Toll Free",
                4: "Premium Rate",
                5: "Shared Cost",
                6: "VoIP",
                7: "Personal Number",
                8: "Pager",
                9: "Universal Access",
                10: "Unknown",
            }
            line_type = type_map.get(num_type, "Unknown")

            tz = list(pn_tz.time_zones_for_number(parsed))
            is_mobile = num_type in (1, 2)

            wa_link = f"https://wa.me/{e164.lstrip('+')}" if is_mobile else None
            tg_link = f"https://t.me/{e164.lstrip('+')}" if is_mobile else None

            digits_only = re.sub(r"\D", "", e164)
            possible_handles = self._make_handles(digits_only, country_iso)

            country_info = COUNTRY_INFO.get(country_iso, {})

            # Multiple format outputs
            formats = {
                "e164": e164,
                "international": international,
                "national": national,
                "rfc3966": rfc3966,
                "digits_only": digits_only,
                "local_with_prefix": self._local_format(digits_only, country_iso),
                "url_encoded": e164.replace("+", "%2B"),
                "tel_link": f"tel:{e164}",
            }

            data = {
                "input": phone,
                "e164": e164,
                "national": national,
                "international": international,
                "rfc3966": rfc3966,
                "country_code": parsed.country_code,
                "country": country_name,
                "country_iso": country_iso,
                "country_info": country_info,
                "location": location,
                "provider": prov or "Unknown",
                "line_type": line_type,
                "is_mobile": is_mobile,
                "timezones": tz,
                "valid": True,
                "possible": phonenumbers.is_possible_number(parsed),
                "whatsapp_link": wa_link,
                "telegram_link": tg_link,
                "possible_handles": possible_handles,
                "formats": formats,
                "timestamp": datetime.now().isoformat(),
            }

            sources = ["phonenumbers-lib"]
            if prov and prov != "Unknown":
                sources.append("provider_db")
            if country_info:
                sources.append("country_db")

            return self.create_result(phone, data, sources)

        except Exception as e:
            return self.error_result(phone, str(e))

    def _local_format(self, digits: str, country: str) -> str:
        """Country-specific local format (without country code)."""
        if not country:
            return digits
        info = COUNTRY_INFO.get(country, {})
        prefix = info.get("whatsapp_prefix")
        if prefix and digits.startswith(prefix):
            # Most countries use leading 0 for local format
            if country in ("ID", "GB", "MY", "AU", "PH", "TH", "VN"):
                return "0" + digits[len(prefix):]
            elif country == "SG":
                return digits[len(prefix):]
            else:
                return digits[len(prefix):]
        return digits

    def _make_handles(self, digits: str, country: str) -> List[str]:
        handles = []

        handles.append(digits)

        if len(digits) >= 7:
            handles.append(digits[-7:])
        if len(digits) >= 8:
            handles.append(digits[-8:])
        if len(digits) >= 9:
            handles.append(digits[-9:])
        if len(digits) >= 10:
            handles.append(digits[-10:])

        if country == "ID" and digits.startswith("62"):
            handles.append("0" + digits[2:])
        elif country == "GB" and digits.startswith("44"):
            handles.append("0" + digits[2:])
        elif country == "MY" and digits.startswith("60"):
            handles.append("0" + digits[2:])
        elif country == "IN" and digits.startswith("91"):
            handles.append(digits[2:])
        elif country == "AU" and digits.startswith("61"):
            handles.append("0" + digits[2:])
        elif country == "SG" and digits.startswith("65"):
            handles.append(digits[2:])
        elif country == "PH" and digits.startswith("63"):
            handles.append("0" + digits[2:])
        elif country == "TH" and digits.startswith("66"):
            handles.append("0" + digits[2:])
        elif country == "VN" and digits.startswith("84"):
            handles.append("0" + digits[2:])

        if len(digits) >= 10:
            handles.append(digits[:4] + "-" + digits[4:7] + "-" + digits[7:])
            handles.append(digits[:3] + "-" + digits[3:6] + "-" + digits[6:])

        handles = list(dict.fromkeys(handles))
        handles = [h for h in handles if len(h) >= 6 and h.isdigit()]

        return handles[:10]

    def get_country_info(self, country_iso: str) -> Dict:
        return COUNTRY_INFO.get(country_iso, {})
