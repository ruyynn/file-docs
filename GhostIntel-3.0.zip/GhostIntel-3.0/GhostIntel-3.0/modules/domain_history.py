#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Domain Age & History module"""

import asyncio
from datetime import datetime
from typing import Dict, Optional
import aiohttp

from modules.base import BaseModule


class DomainHistoryModule(BaseModule):
    """Check domain registration date, expiration, and historical snapshots."""

    def __init__(self, session):
        super().__init__(session)
        self.name = "domain_history"

    async def scan(self, domain: str) -> Dict:
        domain = domain.lower().strip()
        if "://" in domain:
            from urllib.parse import urlparse
            domain = urlparse(domain).netloc.split(":")[0]
        if domain.startswith("www."):
            domain = domain[4:]

        whois_info = await self._whois_lookup(domain)
        archive_snapshots = await self._archive_snapshots(domain)
        wayback_count = await self._wayback_count(domain)

        result = {
            "domain": domain,
            "registrar": whois_info.get("registrar"),
            "creation_date": whois_info.get("creation_date"),
            "expiration_date": whois_info.get("expiration_date"),
            "updated_date": whois_info.get("updated_date"),
            "age_days": whois_info.get("age_days"),
            "age_years": whois_info.get("age_years"),
            "expires_in_days": whois_info.get("expires_in_days"),
            "name_servers_history": whois_info.get("name_servers", []),
            "registrant_country": whois_info.get("country"),
            "registrant_org": whois_info.get("org"),
            "whois_status": whois_info.get("status"),
            "archive_snapshots": archive_snapshots.get("snapshots", []),
            "archive_total": archive_snapshots.get("total", 0),
            "archive_first": archive_snapshots.get("first"),
            "archive_last": archive_snapshots.get("last"),
            "wayback_total_pages": wayback_count,
            "timestamp": datetime.now().isoformat(),
        }

        sources = ["whois"]
        if archive_snapshots.get("total"):
            sources.append("archive.org")
        if wayback_count:
            sources.append("wayback")

        return self.create_result(domain, result, sources)

    async def _whois_lookup(self, domain: str) -> Dict:
        info: Dict = {}
        try:
            import whois  # python-whois

            loop = asyncio.get_event_loop()
            w = await loop.run_in_executor(None, whois.whois, domain)

            if w:
                info["registrar"] = w.registrar if hasattr(w, "registrar") else None
                creation = w.creation_date if hasattr(w, "creation_date") else None
                expiration = w.expiration_date if hasattr(w, "expiration_date") else None
                updated = w.updated_date if hasattr(w, "updated_date") else None
                info["creation_date"] = self._norm_date(creation)
                info["expiration_date"] = self._norm_date(expiration)
                info["updated_date"] = self._norm_date(updated)
                info["name_servers"] = list(w.name_servers) if hasattr(w, "name_servers") and w.name_servers else []
                info["country"] = w.country if hasattr(w, "country") else None
                info["org"] = w.org if hasattr(w, "org") else None
                info["status"] = w.status[0] if hasattr(w, "status") and w.status else None

                now = datetime.utcnow()
                if info["creation_date"]:
                    try:
                        cd = datetime.strptime(info["creation_date"][:10], "%Y-%m-%d")
                        age = (now - cd).days
                        info["age_days"] = age
                        info["age_years"] = round(age / 365.25, 2)
                    except Exception:
                        pass
                if info["expiration_date"]:
                    try:
                        ed = datetime.strptime(info["expiration_date"][:10], "%Y-%m-%d")
                        info["expires_in_days"] = (ed - now).days
                    except Exception:
                        pass
        except Exception:
            pass
        return info

    def _norm_date(self, val) -> Optional[str]:
        if not val:
            return None
        if isinstance(val, list):
            val = val[0] if val else None
            if not val:
                return None
        if isinstance(val, datetime):
            return val.isoformat()
        return str(val)

    async def _archive_snapshots(self, domain: str) -> Dict:
        """Fetch a few snapshots from the Wayback Machine availability API."""
        out: Dict = {"snapshots": [], "total": 0, "first": None, "last": None}
        url = f"https://archive.org/wayback/available?url={domain}"
        try:
            async with self.session.get(
                url, timeout=aiohttp.ClientTimeout(total=8)
            ) as r:
                if r.status != 200:
                    return out
                data = await r.json(content_type=None)
                snaps = data.get("archived_snapshots", {}).get("closest", {})
                if snaps:
                    out["snapshots"] = [
                        {
                            "url": snaps.get("url"),
                            "timestamp": snaps.get("timestamp"),
                            "status": snaps.get("status"),
                            "available": snaps.get("available"),
                        }
                    ]
                    out["total"] = 1
                    out["first"] = snaps.get("timestamp")
                    out["last"] = snaps.get("timestamp")
        except Exception:
            pass
        return out

    async def _wayback_count(self, domain: str) -> int:
        """Count approximate number of Wayback captures."""
        url = f"http://archive.org/wayback/available?url={domain}&timestamp=20000101"
        try:
            async with self.session.get(
                url, timeout=aiohttp.ClientTimeout(total=8)
            ) as r:
                if r.status == 200:
                    return 1  # API only returns closest; precise count needs CDX
        except Exception:
            pass
        return 0
