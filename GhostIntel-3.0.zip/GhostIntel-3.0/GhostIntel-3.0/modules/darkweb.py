#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Dark web monitoring (BETA)

Note: This module scrapes public paste sites and known indexes.
It is NOT a Tor-onion crawler and does not access illegal content.
For research / educational purposes only.
"""

import asyncio
import re
from datetime import datetime
from typing import Dict, List
import aiohttp

from modules.base import BaseModule


class DarkWebModule(BaseModule):
    """Scan public paste sites and leak indexes for a keyword."""

    PASTE_SOURCES = [
        # Public paste sites (clearnet) — searched for keyword
        {"name": "Pastebin (public)", "url": "https://pastebin.com/u/{}"},
        {"name": "Ghostbin", "url": "https://ghostbin.com/users/{}"},
        {"name": "Paste.ee", "url": "https://paste.ee/users/{}"},
    ]

    # Public RSS / search endpoints — used for keyword monitoring
    SEARCH_ENDPOINTS = [
        "https://pastebin.com/u/{}",  # user-profile page
    ]

    def __init__(self, session):
        super().__init__(session)
        self.name = "darkweb"

    async def scan(self, target: str) -> Dict:
        target = target.strip()
        if not target:
            return self.error_result(target, "Empty target")

        results = await asyncio.gather(
            self._scan_paste_sites(target),
            self._scan_leak_forums(target),
            self._check_ahmia(target),  # Ahmia (clearnet search for onion sites)
        )

        pastes, forums, ahmia = results
        all_hits = pastes + forums + ahmia
        risk = min(100, len(all_hits) * 15)

        result = {
            "target": target,
            "pastes_found": pastes,
            "forum_mentions": forums,
            "onion_mentions": ahmia,
            "total_hits": len(all_hits),
            "risk_score": risk,
            "risk_level": self._risk_level(risk),
            "note": (
                "Beta feature — only public paste sites and clearnet indexes "
                "are searched. This is not an exhaustive dark-web scan."
            ),
            "checked_at": datetime.now().isoformat(),
            "timestamp": datetime.now().isoformat(),
        }

        sources = []
        if pastes:
            sources.append("paste_sites")
        if forums:
            sources.append("forums")
        if ahmia:
            sources.append("ahmia")
        return self.create_result(target, result, sources)

    def _risk_level(self, score: int) -> str:
        if score >= 60:
            return "critical"
        if score >= 40:
            return "high"
        if score >= 20:
            return "medium"
        if score > 0:
            return "low"
        return "none"

    async def _scan_paste_sites(self, target: str) -> List[Dict]:
        hits = []
        for src in self.PASTE_SOURCES:
            url = src["url"].format(target)
            try:
                async with self.session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=8),
                    allow_redirects=True,
                    ssl=False,
                ) as r:
                    if r.status == 200:
                        text = await r.text(errors="ignore", limit=200000)
                        # Look for actual content (not 404 page)
                        if "not found" in text.lower()[:2000]:
                            continue
                        hits.append({
                            "source": src["name"],
                            "url": str(r.url),
                            "status": r.status,
                            "size": len(text),
                        })
            except Exception:
                continue
        return hits

    async def _scan_leak_forums(self, target: str) -> List[Dict]:
        """Search public leak-search aggregators (clearnet)."""
        hits = []
        # Use a generic search request — be polite, single attempt
        try:
            url = f"https://www.google.com/search?q={target}+site:pastebin.com"
            async with self.session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=8),
                ssl=False,
                headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64)"},
            ) as r:
                if r.status == 200:
                    text = await r.text(errors="ignore", limit=100000)
                    # Count result links
                    matches = re.findall(r"pastebin\.com/\w+", text)
                    if matches:
                        hits.append({
                            "source": "google_aggregator",
                            "mentions": len(matches),
                            "sample_urls": list(set(matches))[:5],
                        })
        except Exception:
            pass
        return hits

    async def _check_ahmia(self, target: str) -> List[Dict]:
        """Ahmia is a clearnet search engine for .onion services (legal use)."""
        hits = []
        try:
            url = f"https://ahmia.fi/search/?q={target}"
            async with self.session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=10),
                ssl=False,
                headers={"User-Agent": "Mozilla/5.0"},
            ) as r:
                if r.status == 200:
                    text = await r.text(errors="ignore", limit=200000)
                    # Count onion links found
                    onion_links = re.findall(r"https?://[a-z0-9]{16}\.onion", text)
                    if onion_links:
                        hits.append({
                            "source": "ahmia.fi",
                            "onion_results": len(onion_links),
                            "sample": list(set(onion_links))[:3],
                        })
        except Exception:
            pass
        return hits
