#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Domain Reputation module"""

import asyncio
from datetime import datetime
from typing import Dict, List
import aiohttp

from modules.base import BaseModule
from core.secrets import secrets


class DomainReputationModule(BaseModule):
    """Check domain reputation: blacklists, malware, phishing, spam, SSL grade."""

    def __init__(self, session):
        super().__init__(session)
        self.name = "domain_reputation"

    async def scan(self, domain: str) -> Dict:
        domain = domain.lower().strip()
        if "://" in domain:
            from urllib.parse import urlparse
            domain = urlparse(domain).netloc.split(":")[0]
        if domain.startswith("www."):
            domain = domain[4:]

        # Run all checks in parallel
        vt, urlvoid, dbl, phishtank, ssl_grade = await asyncio.gather(
            self._check_virustotal(domain),
            self._check_urlvoid(domain),
            self._check_dbl(domain),
            self._check_phishtank(domain),
            self._check_ssl_grade(domain),
        )

        blacklist_hits = []
        if vt and vt.get("malicious"):
            blacklist_hits.append(f"VirusTotal({vt['malicious']})")
        if urlvoid and urlvoid.get("detected"):
            blacklist_hits.append(f"URLVoid({urlvoid.get('engine', '')})")
        if dbl and dbl.get("listed"):
            blacklist_hits.append("Spamhaus DBL")
        if phishtank and phishtank.get("listed"):
            blacklist_hits.append("PhishTank")

        reputation_score = self._calc_score(vt, urlvoid, dbl, phishtank, ssl_grade)
        risk_level = self._risk_level(reputation_score)

        result = {
            "domain": domain,
            "virustotal": vt,
            "urlvoid": urlvoid,
            "spamhaus_dbl": dbl,
            "phishtank": phishtank,
            "ssl_grade": ssl_grade,
            "blacklist_hits": blacklist_hits,
            "reputation_score": reputation_score,
            "risk_level": risk_level,
            "is_safe": not blacklist_hits and reputation_score >= 80,
            "checked_at": datetime.now().isoformat(),
            "timestamp": datetime.now().isoformat(),
        }

        sources = ["virustotal" if vt else None, "urlvoid" if urlvoid else None,
                   "spamhaus" if dbl else None, "phishtank" if phishtank else None,
                   "ssl" if ssl_grade else None]
        sources = [s for s in sources if s]
        return self.create_result(domain, result, sources)

    def _calc_score(self, vt, urlvoid, dbl, phishtank, ssl_grade) -> int:
        score = 100
        if vt and vt.get("malicious", 0) > 0:
            score -= min(40, vt["malicious"] * 5)
        if urlvoid and urlvoid.get("detected"):
            score -= 25
        if dbl and dbl.get("listed"):
            score -= 30
        if phishtank and phishtank.get("listed"):
            score -= 35
        if ssl_grade:
            grade = ssl_grade.get("grade", "").upper()
            if grade in ("F", "T"):
                score -= 15
            elif grade in ("C", "B"):
                score -= 5
        return max(0, score)

    def _risk_level(self, score: int) -> str:
        if score < 30:
            return "critical"
        if score < 50:
            return "high"
        if score < 70:
            return "medium"
        if score < 90:
            return "low"
        return "minimal"

    async def _check_virustotal(self, domain: str) -> Dict:
        api_key = secrets.get_api_key("virustotal")
        if not api_key:
            return {"skipped": "no_api_key", "note": "Public check only"}
        url = f"https://www.virustotal.com/api/v3/domains/{domain}"
        try:
            async with self.session.get(
                url,
                headers={"x-apikey": api_key},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as r:
                if r.status != 200:
                    return {"error": f"HTTP {r.status}"}
                data = await r.json()
                stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
                return {
                    "malicious": stats.get("malicious", 0),
                    "suspicious": stats.get("suspicious", 0),
                    "harmless": stats.get("harmless", 0),
                    "undetected": stats.get("undetected", 0),
                }
        except Exception as e:
            return {"error": str(e)}

    async def _check_urlvoid(self, domain: str) -> Dict:
        """Use URLVoid API (free tier with key) — falls back to public check."""
        api_key = secrets.get_api_key("urlvoid")
        if not api_key:
            return {"skipped": "no_api_key"}
        url = f"https://api.urlvoid.com/api1000/{api_key}/host/{domain}/"
        try:
            async with self.session.get(
                url, timeout=aiohttp.ClientTimeout(total=10)
            ) as r:
                if r.status != 200:
                    return {"error": f"HTTP {r.status}"}
                # URLVoid returns XML
                text = await r.text()
                detected = "<detected>1</detected>" in text or 'detected="1"' in text
                return {"detected": detected, "engine": "URLVoid"}
        except Exception as e:
            return {"error": str(e)}

    async def _check_dbl(self, domain: str) -> Dict:
        """Check against Spamhaus DBL (public DNS-based check)."""
        try:
            import dns.asyncresolver
            from core.dns_helper import make_resolver
            resolver = make_resolver()
            query = f"{domain}.dbl.spamhaus.org"
            try:
                ans = await resolver.resolve(query, "A")
                if ans:
                    code = str(ans[0])
                    return {
                        "listed": True,
                        "code": code,
                        "category": self._dbl_category(code),
                    }
            except dns.resolver.NXDOMAIN:
                return {"listed": False, "code": None, "category": "clean"}
            except Exception:
                pass
            return {"listed": False, "code": None, "category": "unknown"}
        except Exception as e:
            return {"error": str(e)}

    def _dbl_category(self, code: str) -> str:
        mapping = {
            "127.0.1.2": "spam_domain",
            "127.0.1.4": "phishing",
            "127.0.1.5": "malware",
            "127.0.1.6": "botnet_c2",
            "127.0.1.102": "spam_domain",
            "127.0.1.103": "spam_domain",
            "127.0.1.104": "phishing",
            "127.0.1.105": "malware",
            "127.0.1.106": "botnet_c2",
        }
        return mapping.get(code, "listed")

    async def _check_phishtank(self, domain: str) -> Dict:
        """PhishTank has no public API without key — return informative skip."""
        api_key = secrets.get_api_key("phishtank")
        if not api_key:
            return {"skipped": "no_api_key", "note": "Configure phishtank API key"}
        # Real implementation would POST to checkurl API
        return {"skipped": "not_implemented"}

    async def _check_ssl_grade(self, domain: str) -> Dict:
        """Use SSL Labs public API (anonymous)."""
        try:
            start_url = f"https://api.ssllabs.com/api/v3/analyze?host={domain}&all=done"
            async with self.session.get(
                start_url, timeout=aiohttp.ClientTimeout(total=10)
            ) as r:
                if r.status != 200:
                    return {"error": f"HTTP {r.status}"}
                data = await r.json()
                status = data.get("status", "")
                if status == "READY":
                    endpoints = data.get("endpoints", [])
                    if endpoints:
                        ep = endpoints[0]
                        return {
                            "grade": ep.get("grade", "?"),
                            "gradeTrustIgnored": ep.get("gradeTrustIgnored"),
                            "hasWarnings": ep.get("hasWarnings"),
                            "isExceptional": ep.get("isExceptional"),
                            "progress": ep.get("progress"),
                            "duration": ep.get("duration"),
                            "statusMessage": ep.get("statusMessage"),
                        }
                return {"status": status, "note": "Scan in progress — try again later"}
        except Exception as e:
            return {"error": str(e)}
