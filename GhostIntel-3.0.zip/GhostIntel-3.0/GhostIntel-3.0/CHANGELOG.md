# Changelog

All notable changes to GhostIntel are documented here.
Format is loosely based on Keep a Changelog — dates are YYYY-MM-DD.

---

## [3.0.0] — 2026-08-17

Major upgrade. New modules, infrastructure, and UX work across the board.

### Added
- **Config file support** — `~/.ghostintel/config.yaml` for defaults, monitoring,
  notifications, proxy, and optional API keys. Auto-detected if present.
  Run `python ghostintel.py --config-init` to write a sample.
- **Live monitoring** — `--monitor --interval N` re-scans a target and
  reports changes (new platforms, IPs, breaches, etc.) against a baseline.
- **Telegram & Discord notifications** — wire up `notifications.telegram`
  (`BOT_TOKEN:CHAT_ID`) or `notifications.discord_webhook` in config, or use
  `--notify-telegram` / `--notify-discord URL` on the command line.
- **Social-media scraping** — `--scrape` extracts profile metadata (name,
  description, avatar, stats) from supported platforms instead of just
  checking existence.
- **Domain age & history** — `--domain-history` module returns registrar,
  creation/expiration dates, age in years, and Wayback Machine snapshots.
- **Domain reputation** — `--domain-reputation` checks VirusTotal, URLVoid,
  Spamhaus DBL, PhishTank, and SSL Labs grade. Computes a reputation score
  and risk level.
- **Live breach check** — `--breach-live` queries HaveIBeenPwned when an API
  key is provided, with a local public-breach DB fallback. Includes paste
  site mentions and password breach check (k-anonymity).
- **Dark-web monitoring (BETA)** — `--darkweb-monitor` searches public paste
  sites and the Ahmia clearnet index for .onion mentions of a target.
- **Username availability checker** — `--availability` inverse check that
  reports which platforms do *not* yet have the given username.
- **International phone formatter** — `--format-all` outputs every phone
  format variant (E.164, international, national, RFC3966, digits, local,
  URL-encoded, tel: link).
- **HTTP/SOCKS5 proxy support** — `--proxy URL` routes all HTTP through a
  proxy. `--tor` is a shortcut for `socks5://127.0.0.1:9050`.
- **Optional API keys** — tools run fully without keys. Set
  `GHOSTINTEL_<SERVICE>_API_KEY` env vars, add them under `api_keys:` in
  config, or pass `--api service=key` inline.
- **Multi-language UI** — `--lang id` for Bahasa Indonesia, `--lang en`
  for English (default).
- **Rate limiting & caching** — modules now share a base class with
  per-request rate limiting, exponential-backoff retries, and TTL caching.
- **Version check & update** — `--update-check` polls GitHub releases and
  tells you if a newer version is available.
- **JSON schema validation** — reports are wrapped in a v3.0 schema
  envelope and validated before write.
- **Interactive HTML dashboard** — Chart.js doughnut (category distribution),
  bar (timeline), and a risk gauge. Light/dark theme toggle.
- **`--credit`** — shows author credit and Saweria support link.
- **`--changelog`** — prints this file.
- **`-h -a` / `--help --all`** — full detailed manual; bare `-h` shows a
  compact help.
- **230+ → 380 username platforms** (well above the 230+ target).
- **Phone OSINT: 8 → 10 countries** — added Thailand (AIS, DTAC, True Move,
  TOT, CAT) and Vietnam (Viettel, Vinaphone, Mobifone, Vietnamobile, Wintel,
  Gmobile).

### Changed
- Help menu redesigned: compact `-h` and full `-h -a` modes.
- Banner simplified — fewer emojis, cleaner ASCII art.
- Web UI rewritten with sidebar layout, scan history, theme toggle, and
  inline result rendering.
- Engine now initializes new modules (domain_history, domain_reputation,
  breach_live, darkweb) and routes deep investigation through the right
  module map per target type.
- HTML report uses Chart.js for visualization with offline-friendly CDN.
- TXT and Markdown reports cleaned up (no emoji clutter).

### Fixed
- `proxy.py` no longer passes `force_close` twice to `aiohttp.TCPConnector`.
- `core/utils.py` now exports `print_credit`, `print_changelog` consistently.
- Phone module correctly maps Thailand and Vietnam number ranges.
- Domain module handles missing SSL info without throwing.
- Batch processing no longer crashes when one target fails — continues
  to the next and reports the failure in the summary.

---

## [2.5.0] — 2026-03-29

### Added
- **Web UI** — first localhost dashboard (port 7331).
- **Phone OSINT: 5 → 8 countries** — added Australia, Singapore, Philippines.
- **Email breach detection** — local public-breach DB + risk score (0-100).
- **Batch processing** — `--batch targets.txt` for multi-target scans.
- **Markdown reports** — new output format alongside JSON/HTML/TXT.
- **JSON compression** — `--compress` gzips the JSON report.
- **Rotating User-Agent** — 5+ UAs to avoid simple blocking.
- **SSL/TLS info** — certificate issuer, expiry, days left.
- **DNSSEC check** — domain module reports DNSSEC status.
- **Risk scoring (IP)** — 0-100 score based on proxy/VPN/hosting signals.
- **129+ username platforms** (up from 100+ in v2.0).

---

## [2.0.0] — 2026-01-15

### Added
- **Async scanning** — `aiohttp` + `asyncio`, 10x faster than v1.0.
- **5 country phone OSINT** — ID, US, GB, MY, IN.
- **Auto-detection** — paste any target, GhostIntel figures out the type.
- **Multi-format reports** — JSON, HTML, TXT.
- **100+ username platforms** — social, dev, gaming, music, video.
- **Domain tech stack detection** — 50+ patterns (CMS, frameworks, servers).
- **IP geolocation** — multi-API fallback (ip-api, ipapi.co, ipinfo.io).
- **RDAP lookup** — all five RIRs with abuse contact extraction.
- **DNS resolver fallback** — Google + Cloudflare + Quad9 + OpenDNS.
- **Data correlation engine** — connects entities across modules.

---

## [1.0.0] — 2025-11-01

### Added
- Initial release.
- Username check across 30 platforms.
- Basic email validation (format + MX).
- Domain DNS lookup (A, MX, NS, TXT).
- Simple JSON output.

---

Notes:
- This tool is for **educational purposes and authorized security research
  only**. The author (Ruyynn) is not responsible for any misuse.
- Support development at https://saweria.co/Ruyynn
