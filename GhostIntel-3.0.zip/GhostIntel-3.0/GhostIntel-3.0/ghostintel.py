#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Advanced OSINT Framework

Educational / authorized-research use only.
"""

import asyncio
import argparse
import sys
import os
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

from core.banner import show_banner, console, VERSION, AUTHOR, GITHUB, SAWERIA
from core.engine import GhostIntelEngine
from core.utils import (
    print_help, print_version, print_credit, print_changelog,
    sanitize_filename,
)
from core.i18n import i18n
from core.config import get_config, ConfigLoader
from core.notifier import Notifier
from core.monitor import Monitor
from reports.generator import ReportGenerator


def parse_arguments():
    parser = argparse.ArgumentParser(
        description=f"GhostIntel v{VERSION} — Advanced OSINT Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        add_help=False,
    )

    # Main command
    parser.add_argument("command", nargs="?", choices=["investigate", "scan", "help"],
                        help="Command: investigate (default), scan, help")
    parser.add_argument("target", nargs="?", help="Target to investigate")

    # Investigation flags
    parser.add_argument("-u", "--username", metavar="USERNAME", help="Investigate username")
    parser.add_argument("-e", "--email", metavar="EMAIL", help="Investigate email")
    parser.add_argument("-p", "--phone", metavar="PHONE", help="Investigate phone number")
    parser.add_argument("-d", "--domain", metavar="DOMAIN", help="Investigate domain")
    parser.add_argument("-i", "--ip", metavar="IP", help="Investigate IP address")

    # Username options
    parser.add_argument("--scrape", action="store_true",
                        help="Scrape profile metadata from found accounts")
    parser.add_argument("--availability", action="store_true",
                        help="Check username availability (inverse check)")

    # Email / breach
    parser.add_argument("--breach-live", action="store_true",
                        help="Real-time breach check via HIBP (key optional)")
    parser.add_argument("--breach-monitor", action="store_true",
                        help="Periodically re-check breaches (use with -e)")

    # Phone options
    parser.add_argument("--format-all", action="store_true",
                        help="Output all phone format variants")

    # Domain options
    parser.add_argument("--domain-history", action="store_true",
                        help="Domain age + WHOIS + Wayback snapshots")
    parser.add_argument("--domain-reputation", action="store_true",
                        help="Domain reputation: blacklists / malware / SSL grade")

    # Dark-web
    parser.add_argument("--darkweb-monitor", action="store_true",
                        help="Monitor dark-web mentions (beta)")
    parser.add_argument("--darkweb-interval", type=int, default=120,
                        help="Seconds between dark-web scans (default: 120)")

    # Web UI
    parser.add_argument("-web", "--web", action="store_true", help="Launch web UI")
    parser.add_argument("--port", type=int, default=7331, help="Web UI port (default: 7331)")
    parser.add_argument("--no-browser", action="store_true", help="Don't open browser")

    # Report options
    parser.add_argument("--report", action="store_true", help="Generate report")
    parser.add_argument("-o", "--output", metavar="FILE", help="Save report to file")
    parser.add_argument("--output-dir", metavar="DIR", default="output",
                        help="Output directory (default: output)")
    parser.add_argument("--format", choices=["json", "html", "txt", "md", "all"],
                        default="json", help="Output format (default: json)")
    parser.add_argument("--compress", action="store_true",
                        help="Gzip the JSON report")

    # Batch processing
    parser.add_argument("--batch", metavar="FILE",
                        help="Batch scan: one target per line")
    parser.add_argument("--batch-delay", type=float, default=1.0,
                        help="Delay between batch scans (default: 1.0s)")

    # Investigation options
    parser.add_argument("--timeout", type=int, default=12,
                        help="Request timeout in seconds (default: 12)")
    parser.add_argument("--threads", type=int, default=25,
                        help="Concurrent workers (default: 25)")
    parser.add_argument("--deep", action="store_true",
                        help="Deep investigation (all relevant modules)")

    # Monitoring
    parser.add_argument("--monitor", action="store_true",
                        help="Live-monitor target and notify on changes")
    parser.add_argument("--interval", type=int, default=300,
                        help="Monitor interval in seconds (min 60, default: 300)")
    parser.add_argument("--notify-telegram", action="store_true",
                        help="Send change notifications to Telegram (config: notifications.telegram)")
    parser.add_argument("--notify-discord", metavar="WEBHOOK",
                        help="Send change notifications to a Discord webhook")

    # Config / proxy / security
    parser.add_argument("--config", action="store_true",
                        help="Load ~/.ghostintel/config.yaml")
    parser.add_argument("--config-init", action="store_true",
                        help="Write a sample config to ~/.ghostintel/config.yaml and exit")
    parser.add_argument("--proxy", metavar="URL",
                        help="Proxy URL (http://host:port or socks5://host:port)")
    parser.add_argument("--tor", action="store_true",
                        help="Route via local Tor (socks5://127.0.0.1:9050)")
    parser.add_argument("--api", "-api", metavar="SERVICE=KEY", action="append",
                        help="API key inline (e.g. --api hibp=xxxx). Repeatable.")
    parser.add_argument("--lang", choices=["en", "id"], default="en",
                        help="Interface language (default: en)")

    # Output options
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--quiet", action="store_true", help="Suppress output (only save report)")

    # Meta
    parser.add_argument("-h", "--help", action="store_true", help="Show help")
    parser.add_argument("-a", "--all", action="store_true",
                        help="With --help, show the full detailed manual")
    parser.add_argument("-v", "--version", action="store_true", help="Show version")
    parser.add_argument("--credit", action="store_true", help="Show credits & support")
    parser.add_argument("--changelog", action="store_true", help="Show changelog")
    parser.add_argument("--update-check", action="store_true", help="Check for new release")
    parser.add_argument("--debug", action="store_true", help="Enable debug output")

    return parser.parse_args()


def apply_inline_api_keys(api_args):
    """Inject --api SERVICE=KEY entries into the environment."""
    if not api_args:
        return
    for item in api_args:
        if "=" not in item:
            continue
        service, _, key = item.partition("=")
        env_key = f"GHOSTINTEL_{service.strip().upper()}_API_KEY"
        os.environ[env_key] = key.strip()


async def batch_scan(targets: list, args) -> dict:
    results = {}
    engine = GhostIntelEngine(
        timeout=args.timeout,
        max_concurrent=args.threads,
        proxy=args.proxy,
        tor=args.tor,
        scrape=args.scrape,
        lang=args.lang,
    )

    console.print(f"\n[bold cyan]Batch scanning {len(targets)} targets[/bold cyan]\n")

    async with engine:
        for idx, target in enumerate(targets, 1):
            target = target.strip()
            if not target or target.startswith('#'):
                continue

            console.print(f"[{idx}/{len(targets)}] Scanning: [yellow]{target}[/yellow]")

            try:
                from core.detector import detector
                entity = detector.detect(target)
                target_type = entity.type
                norm_target = entity.normalized

                if args.deep:
                    result = await engine.investigate_all(norm_target, target_type)
                else:
                    result = await engine.investigate(norm_target, target_type)

                if result:
                    results[target] = result
                    console.print("  [green]✓ done[/green]")
                else:
                    console.print("  [yellow]! no results[/yellow]")

            except Exception as e:
                console.print(f"  [red]✗ {e}[/red]")
                if args.debug:
                    import traceback
                    traceback.print_exc()

            if idx < len(targets):
                await asyncio.sleep(args.batch_delay)

    return results


async def run_monitor(args):
    """Set up and run live monitoring."""
    target, target_type = _pick_target(args)
    if not target:
        console.print("[red]✗ No target for monitor[/red]")
        return

    # Build engine factory (fresh session each iteration)
    def factory():
        return GhostIntelEngine(
            timeout=args.timeout,
            max_concurrent=args.threads,
            proxy=args.proxy,
            tor=args.tor,
            scrape=args.scrape,
            lang=args.lang,
        )

    notifier = Notifier()
    if args.notify_telegram and not notifier.telegram_target:
        console.print("[yellow]! Telegram target not configured. "
                      "Set notifications.telegram in ~/.ghostintel/config.yaml[/yellow]")
    if args.notify_discord:
        notifier.discord_webhook = args.notify_discord

    mon = Monitor(
        engine_factory=factory,
        target=target,
        target_type=target_type,
        interval=args.interval,
        deep=True,
        notifier=notifier,
    )

    try:
        await mon.run()
    except KeyboardInterrupt:
        mon.stop()


def _pick_target(args):
    if args.username:
        return args.username, "username"
    if args.email:
        return args.email, "email"
    if args.phone:
        return args.phone, "phone"
    if args.domain:
        return args.domain, "domain"
    if args.ip:
        return args.ip, "ip"
    if args.target:
        return args.target, "auto"
    return None, None


async def main_async():
    args = parse_arguments()

    # Apply inline API keys
    apply_inline_api_keys(args.api)

    # Load config (auto if file exists, or if --config is set)
    cfg = get_config()
    if args.config_init:
        path = ConfigLoader.write_example()
        console.print(f"[green]✓ Sample config written to {path}[/green]")
        return
    if cfg.path.exists() and not args.config:
        # Auto-loaded
        pass
    if args.config and not cfg.path.exists():
        ConfigLoader.write_example()
        cfg = ConfigLoader()  # reload
        console.print(f"[green]✓ Config loaded from {cfg.path}[/green]")

    # Language
    if args.lang:
        i18n.set_lang(args.lang)

    # Meta commands
    if args.version:
        print_version()
        return
    if args.credit:
        print_credit()
        return
    if args.changelog:
        print_changelog()
        return
    if args.update_check:
        from core.updater import print_update_check
        print_update_check()
        return
    if args.help or args.command == "help":
        print_help(show_all=args.all)
        return

    # Web UI
    if args.web:
        from web.server import start_web_server
        if not args.no_color:
            show_banner()
        start_web_server(port=args.port, open_browser=not args.no_browser)
        return

    # If no target and no batch — show help
    has_target = any([args.username, args.email, args.phone, args.domain, args.ip,
                      args.target, args.batch])
    if not has_target:
        print_help(show_all=args.all)
        return

    # Banner
    if not args.no_color and not args.quiet:
        show_banner()

    # Proxy info
    if args.proxy or args.tor:
        from core.proxy import ProxyManager
        pm = ProxyManager(args.proxy, args.tor)
        if not args.quiet:
            console.print(f"[dim]Using proxy: {pm.describe()}[/dim]")

    # Monitor mode
    if args.monitor:
        await run_monitor(args)
        return

    # Batch processing
    if args.batch:
        await _run_batch(args)
        return

    # Single target
    await _run_single(args)


async def _run_batch(args):
    try:
        with open(args.batch, 'r', encoding='utf-8') as f:
            targets = [line.strip() for line in f if line.strip() and not line.startswith('#')]

        if not targets:
            console.print("[red]✗ No targets found in batch file[/red]")
            return

        results = await batch_scan(targets, args)

        if results and (args.report or args.output):
            rg = ReportGenerator(output_dir=args.output_dir)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

            if args.format == "all":
                base_name = args.output or f"ghostintel_batch_{timestamp}"
                files = await rg.save_all_formats(results, base_name)
                console.print(f"\n[green]✓ Batch reports saved: {len(files)} files[/green]")
            else:
                fname = args.output or f"ghostintel_batch_{timestamp}.{args.format}"
                if args.format == "json":
                    f = await rg.save_json(results, fname, compress=args.compress)
                elif args.format == "html":
                    f = await rg.save_html(results, fname)
                elif args.format == "txt":
                    f = await rg.save_txt(results, fname)
                elif args.format == "md":
                    f = await rg.save_markdown(results, fname)
                console.print(f"\n[green]✓ Batch report saved: {f}[/green]")

        console.print(f"\n[bold green]Batch Summary:[/bold green]")
        console.print(f"  Total targets: {len(targets)}")
        console.print(f"  Successful: {len(results)}")
        console.print(f"  Failed: {len(targets) - len(results)}")

    except FileNotFoundError:
        console.print(f"[red]✗ Batch file not found: {args.batch}[/red]")
    except Exception as e:
        console.print(f"[red]✗ Batch error: {e}[/red]")
        if args.debug:
            import traceback
            traceback.print_exc()


async def _run_single(args):
    target, target_type = _pick_target(args)

    # Override target_type based on flags
    explicit_type = None
    if args.breach_live and args.email:
        explicit_type = "breach_live"
    elif args.domain_history and args.domain:
        explicit_type = "domain_history"
    elif args.domain_reputation and args.domain:
        explicit_type = "domain_reputation"
    elif args.darkweb_monitor and (args.username or args.email):
        explicit_type = "darkweb"
    elif args.availability and args.username:
        explicit_type = "username"  # availability_mode handled inside module

    engine = GhostIntelEngine(
        timeout=args.timeout,
        max_concurrent=args.threads,
        proxy=args.proxy,
        tor=args.tor,
        scrape=args.scrape,
        lang=args.lang,
    )

    if not target:
        console.print("[red]✗ No target specified[/red]")
        return

    # Determine whether to do deep investigation
    do_deep = (args.report or args.output or args.deep or args.format == "all")

    if do_deep:
        if not args.quiet:
            console.print(f"\n[bold cyan]Deep Investigation: [yellow]{target}[/yellow][/bold cyan]")

        async with engine:
            results = await engine.investigate_all(target, target_type)

        if results:
            rg = ReportGenerator(output_dir=args.output_dir)

            if args.format == "all":
                base_name = args.output or None
                files = await rg.save_all_formats(results, base_name)
                if not args.quiet:
                    console.print(f"\n[green]✓ Reports saved: {len(files)} files[/green]")
            else:
                fname = args.output
                if args.format == "json":
                    f = await rg.save_json(results, fname, compress=args.compress)
                elif args.format == "html":
                    f = await rg.save_html(results, fname)
                elif args.format == "txt":
                    f = await rg.save_txt(results, fname)
                elif args.format == "md":
                    f = await rg.save_markdown(results, fname)
                else:
                    f = await rg.save_json(results, fname)

                if not args.quiet:
                    console.print(f"\n[green]✓ Report saved: {f}[/green]")

            if not args.quiet:
                await engine.display_summary(results)
        else:
            if not args.quiet:
                console.print("[red]✗ No results found[/red]")

    elif explicit_type:
        # Targeted single-module run
        async with engine:
            result = await engine.investigate(target, explicit_type)
            if result and not args.quiet:
                await engine.display_result(result)
            elif not result and not args.quiet:
                console.print("[red]✗ No results found[/red]")

    else:
        # Quick investigation
        async with engine:
            result = await engine.investigate(target, target_type)
            if result and not args.quiet:
                await engine.display_result(result)
            elif not result and not args.quiet:
                console.print("[red]✗ No results found[/red]")


def main():
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main_async())
    except KeyboardInterrupt:
        console.print("\n[yellow]! Interrupted[/yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[red]✗ Fatal: {e}[/red]")
        if "--debug" in sys.argv:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
