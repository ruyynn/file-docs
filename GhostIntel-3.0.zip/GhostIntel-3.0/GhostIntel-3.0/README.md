<div align="center">

<img src="assets/ghost-icon.png" alt="GhostIntel" width="450">

# GhostIntel v3.0

### OSINT Framework — Public Sources · Optional API Keys · Educational Use

**No API keys required** · **380+ platforms** · **10 countries** · **Multi-language**

[![Python](https://img.shields.io/badge/Python-3.8%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![Version](https://img.shields.io/badge/Version-3.0.0-00aced?style=for-the-badge&logo=git&logoColor=white)]()
[![GitHub Stars](https://img.shields.io/github/stars/ruyynn/GhostIntel?style=for-the-badge&logo=github&logoColor=white&color=gold)](https://github.com/ruyynn/GhostIntel/stargazers)
[![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge&logo=opensourceinitiative&logoColor=white)](LICENSE)
[![Made in Indonesia](https://img.shields.io/badge/MADE_IN-INDONESIA-red?style=for-the-badge&logo=ko-fi&logoColor=white)]()

</div>

---

## About

GhostIntel is an OSINT framework for investigating publicly available data
about usernames, emails, phone numbers, domains, and IP addresses. It is
built for **educational purposes and authorized security research**.

All data is sourced from public records (DNS, RDAP, public websites, public
breach databases). Optional API keys unlock additional sources (HIBP,
VirusTotal, URLVoid, PhishTank, GreyNoise) but the tool works fully
without them.

> By using this tool you accept full responsibility for compliance with all
> applicable laws. The author is not liable for any misuse.

---

## Quick start

```bash
git clone https://github.com/ruyynn/GhostIntel.git
cd GhostIntel
pip install -r requirements.txt
python ghostintel.py -h
```

### Basic usage

```bash
# Username across 380+ platforms
python ghostintel.py -u ryan

# Username + scrape profile metadata
python ghostintel.py -u ryan --scrape

# Which platforms DON'T have this username yet?
python ghostintel.py -u ryan --availability

# Email + breach check
python ghostintel.py -e user@gmail.com

# Live breach check via HIBP (set GHOSTINTEL_HIBP_API_KEY)
python ghostintel.py -e user@gmail.com --breach-live

# Phone OSINT — 10 countries
python ghostintel.py -p 08123456789

# All phone format variants
python ghostintel.py -p 08123456789 --format-all

# Domain recon
python ghostintel.py -d example.com --deep

# Domain age + history + reputation
python ghostintel.py -d example.com --domain-history --domain-reputation

# IP geolocation + risk score
python ghostintel.py -i 8.8.8.8

# Web UI on http://localhost:7331
python ghostintel.py -web

# Batch scan
python ghostintel.py --batch targets.txt --deep --format all
```

---

## What's new in v3.0

- **Config file** — `~/.ghostintel/config.yaml` for defaults, monitoring,
  notifications, proxy, and optional API keys.
- **Live monitoring** — `--monitor` re-scans a target and notifies on changes.
- **Telegram & Discord notifications** — get alerts when something changes.
- **Social-media scraping** — `--scrape` pulls profile metadata, not just
  existence.
- **Domain age & history** — WHOIS + Wayback snapshots.
- **Domain reputation** — blacklists, malware, phishing, SSL grade.
- **Live breach check** — HIBP integration (optional key) + local DB fallback.
- **Dark-web monitoring (BETA)** — public paste sites + Ahmia clearnet index.
- **Username availability** — inverse check across 380+ platforms.
- **International phone formatter** — every format variant in one run.
- **HTTP/SOCKS5 proxy + Tor** — `--proxy` and `--tor` flags.
- **Optional API keys** — tool works fully without keys; add them to unlock
  extra sources.
- **Multi-language UI** — `--lang id` for Bahasa Indonesia.
- **Rate limiting & caching** — shared base class for all modules.
- **Version check** — `--update-check` polls GitHub releases.
- **Interactive HTML dashboard** — Chart.js doughnut, bar, and risk gauge.
- **JSON schema validation** — reports are schema-validated before write.
- **380+ username platforms** (was 129+ in v2.5).
- **10 phone countries** — added Thailand + Vietnam.

See [CHANGELOG.md](CHANGELOG.md) for the full history from v1.0.0 to v3.0.0.

---

## Help system

```bash
python ghostintel.py -h            # compact help
python ghostintel.py -h -a         # full detailed manual
python ghostintel.py --help --all  # same as -h -a
python ghostintel.py --version
python ghostintel.py --credit
python ghostintel.py --changelog
python ghostintel.py --update-check
```

---

## Configuration

```bash
# Write a sample config
python ghostintel.py --config-init
```

The file lands at `~/.ghostintel/config.yaml`. See
[config.example.yaml](config.example.yaml) for the full structure.

### Optional API keys

Set as environment variables, in config, or pass inline:

```bash
# Env var
export GHOSTINTEL_HIBP_API_KEY=your_key_here

# Inline
python ghostintel.py -e user@gmail.com --breach-live --api hibp=your_key_here

# In config.yaml:
# api_keys:
#   hibp: your_key_here
```

Supported services: HIBP, VirusTotal, URLVoid, PhishTank, GreyNoise.

---

## Live monitoring + notifications

```bash
# Re-scan every 5 minutes and alert on changes
python ghostintel.py -u ryan --monitor --interval 300 --notify-telegram

# Dark-web mention monitoring (beta)
python ghostintel.py -u ryan --darkweb-monitor --darkweb-interval 120

# Breach re-check (use with -e)
python ghostintel.py -e user@gmail.com --breach-monitor
```

Wire up Telegram in `~/.ghostintel/config.yaml`:

```yaml
notifications:
  telegram: "BOT_TOKEN:CHAT_ID"
```

Or use Discord:

```yaml
notifications:
  discord_webhook: "https://discord.com/api/webhooks/..."
```

---

## Proxy & Tor

```bash
# HTTP proxy
python ghostintel.py -u ryan --proxy http://proxy.example.com:8080

# SOCKS5 proxy
python ghostintel.py -u ryan --proxy socks5://127.0.0.1:9050

# Tor shortcut (uses socks5://127.0.0.1:9050)
python ghostintel.py -u ryan --tor
```

Install `aiohttp_socks` for SOCKS support: `pip install aiohttp_socks`

---

## Phone OSINT — 10 countries

| Country | Code | Example | Providers |
|---------|------|---------|-----------|
| Indonesia | +62 | `-p 08123456789` | Telkomsel, Indosat, XL, Three, Smartfren |
| USA | +1 | `-p +12125551234` | AT&T, Verizon, T-Mobile |
| UK | +44 | `-p +447700123456` | EE, O2, Vodafone, Three |
| Malaysia | +60 | `-p +60123456789` | Maxis, Celcom, DiGi, U Mobile |
| India | +91 | `-p +919876543210` | Airtel, Vi, Jio, BSNL |
| Australia | +61 | `-p +61412345678` | Telstra, Optus, Vodafone |
| Singapore | +65 | `-p +6581234567` | Singtel, StarHub, M1, SIMBA |
| Philippines | +63 | `-p +639171234567` | Globe, Smart, DITO |
| Thailand | +66 | `-p +66812345678` | AIS, DTAC, True Move |
| Vietnam | +84 | `-p +84912345678` | Viettel, Vinaphone, Mobifone |

Use `--format-all` to output every format variant (E.164, international,
national, RFC3966, digits-only, local, URL-encoded, tel: link).

---

## Report formats

| Format | Command | Use case |
|--------|---------|----------|
| JSON | `--format json` | Machine parsing, integration |
| HTML | `--format html` | Interactive dashboard with charts |
| TXT | `--format txt` | Lightweight, readable anywhere |
| Markdown | `--format md` | Documentation, GitHub |
| All | `--format all` | Generate all four at once |

```bash
# All formats + custom output
python ghostintel.py -u ryan --format all -o ryan_report

# Compressed JSON
python ghostintel.py -e user@gmail.com --format json --compress
```

---

## Web UI

```bash
python ghostintel.py -web                 # default port 7331
python ghostintel.py -web --port 8080     # custom port
python ghostintel.py -web --no-browser    # don't auto-open browser
```

Features: dark/light theme, scan history (saved locally), live type
detection, inline result rendering, deep/quick mode toggle, scrape toggle,
language selector.

---

## Project structure

```
GhostIntel/
├── ghostintel.py           # CLI entry point
├── requirements.txt
├── config.example.yaml     # sample config
├── CHANGELOG.md
├── core/
│   ├── banner.py           # ASCII banner + console
│   ├── engine.py           # main investigation engine
│   ├── detector.py         # entity type auto-detection
│   ├── correlation.py      # cross-module correlation
│   ├── dns_helper.py       # DNS resolver with fallbacks
│   ├── utils.py            # help system, version, credit
│   ├── config.py           # YAML config loader
│   ├── secrets.py          # API key manager
│   ├── proxy.py            # HTTP/SOCKS5 + Tor proxy manager
│   ├── i18n.py             # multi-language strings
│   ├── notifier.py         # Telegram + Discord notifications
│   ├── monitor.py          # live monitoring loop
│   └── updater.py          # GitHub release checker
├── modules/
│   ├── base.py             # base module (rate limit, retry, cache)
│   ├── username.py         # 380+ platforms + scrape + availability
│   ├── email.py            # MX/SPF/DMARC + breach
│   ├── phone.py            # 10 countries + multi-format
│   ├── domain.py           # DNS + HTTP + tech detection
│   ├── ip.py               # geolocation + RDAP + risk
│   ├── domain_history.py   # WHOIS + age + Wayback
│   ├── domain_reputation.py # blacklists + SSL grade
│   ├── breach_live.py      # HIBP + local DB
│   ├── darkweb.py          # paste sites + Ahmia (beta)
│   └── availability.py     # inverse username check
├── sources/
│   ├── social_media.py     # 380+ platform URLs
│   ├── phone_db.py         # provider prefixes for 10 countries
│   └── breach_db.py        # local public breach database
├── reports/
│   ├── generator.py        # multi-format report writer
│   ├── html_template.py    # HTML report with Chart.js
│   ├── json_formatter.py   # JSON helpers
│   └── schema.py           # JSON schema validation
├── web/
│   └── server.py           # Flask web UI
└── assets/                 # images
```

---

## Legal & ethical use

GhostIntel is built for **educational purposes and authorized security
research only**.

- Investigate only targets you own or have explicit permission to test.
- All data is sourced from public records.
- Do NOT use for doxing, stalking, harassment, or any unlawful activity.
- The author is not responsible for any misuse.

By using this tool you accept full responsibility for compliance with all
applicable laws.

---

## Support

If GhostIntel helped you, consider supporting development:

**Saweria:** https://saweria.co/Ruyynn

Star the repo on GitHub — it helps the project grow.

---

## License

MIT License — feel free to use, modify, and distribute with credit to
**Ruyynn**.

---

<div align="center">

**GhostIntel v3.0** · OSINT Framework · Public Sources · Educational Use

© 2026 Ruyynn

</div>
