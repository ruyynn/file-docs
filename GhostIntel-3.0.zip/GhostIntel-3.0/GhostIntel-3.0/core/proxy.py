#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Proxy manager (HTTP/SOCKS5 + Tor)"""

from typing import Optional

try:
    import aiohttp
except ImportError:  # pragma: no cover
    aiohttp = None  # type: ignore

from core.config import get_config


class ProxyManager:
    """Manage proxy configuration for the HTTP session."""

    DEFAULT_TOR_SOCKS5 = "socks5://127.0.0.1:9050"
    DEFAULT_TOR_HTTP = "http://127.0.0.1:8118"

    def __init__(self, proxy_url: Optional[str] = None, tor: bool = False):
        self.proxy_url = proxy_url or get_config().get_proxy()
        self.tor = tor or get_config().use_tor()

    @property
    def effective_proxy(self) -> Optional[str]:
        if self.tor:
            return self.proxy_url or self.DEFAULT_TOR_SOCKS5
        return self.proxy_url

    def is_socks(self) -> bool:
        p = self.effective_proxy
        return bool(p) and p.lower().startswith("socks")

    def build_connector(self, **kwargs):
        """Build an aiohttp connector that routes through the proxy.

        Note: aiohttp natively supports http:// proxies via `proxy=` on the
        request. SOCKS proxies require aiohttp_socks. This helper installs a
        SOCKS-aware connector if aiohttp_socks is available; otherwise it
        falls back to a plain TCPConnector and the caller must pass
        `proxy=` per-request.
        """
        if aiohttp is None:
            raise RuntimeError("aiohttp is required for ProxyManager")

        proxy = self.effective_proxy
        # Pull known connector kwargs out so we don't pass them twice
        limit = kwargs.pop("limit", 50)
        ssl_val = kwargs.pop("ssl", False)
        force_close = kwargs.pop("force_close", True)
        enable_cleanup = kwargs.pop("enable_cleanup_closed", True)
        # remaining kwargs (e.g. resolver, ttl_dns_cache) are forwarded
        common = dict(
            limit=limit,
            ssl=ssl_val,
            force_close=force_close,
            enable_cleanup_closed=enable_cleanup,
            **kwargs,
        )

        if proxy and proxy.lower().startswith("socks"):
            try:
                from aiohttp_socks import ProxyConnector  # type: ignore

                kind = "socks5" if "socks5" in proxy.lower() else "socks4"
                host_port = proxy.split("://", 1)[-1]
                host, _, port = host_port.partition(":")
                # ProxyConnector.from_url accepts a full URL
                return ProxyConnector.from_url(
                    f"{kind}://{host}:{port or '9050'}",
                    rdns=True,
                )
            except ImportError:
                pass

        return aiohttp.TCPConnector(**common)

    def request_kwargs(self) -> dict:
        """Per-request kwargs to pass when making individual HTTP calls."""
        proxy = self.effective_proxy
        if proxy and not proxy.lower().startswith("socks"):
            return {"proxy": proxy}
        return {}

    def describe(self) -> str:
        if not self.effective_proxy:
            return "direct (no proxy)"
        if self.tor:
            return f"Tor via {self.effective_proxy}"
        return f"proxy={self.effective_proxy}"
