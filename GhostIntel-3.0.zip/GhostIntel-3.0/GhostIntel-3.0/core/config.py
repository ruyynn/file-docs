#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Config file loader"""

import os
from pathlib import Path
from typing import Any, Dict, Optional


class ConfigLoader:
    """Load and parse ~/.ghostintel/config.yaml"""

    DEFAULT_PATH = Path.home() / ".ghostintel" / "config.yaml"

    DEFAULTS: Dict[str, Any] = {
        "defaults": {
            "deep": False,
            "format": "json",
            "output_dir": "output",
            "timeout": 12,
            "threads": 25,
            "lang": "en",
        },
        "monitoring": {
            "enabled": False,
            "interval": 300,
        },
        "notifications": {
            "telegram": None,
            "discord_webhook": None,
        },
        "proxy": {
            "url": None,
            "tor": False,
        },
        "api_keys": {},
    }

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else self.DEFAULT_PATH
        self.config = self._deep_merge(self.DEFAULTS, self._load())

    def _deep_merge(self, base: Dict, override: Dict) -> Dict:
        out = dict(base)
        for k, v in (override or {}).items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = self._deep_merge(out[k], v)
            else:
                out[k] = v
        return out

    def _load(self) -> Dict:
        if not self.path.exists():
            return {}
        try:
            import yaml  # type: ignore
        except ImportError:
            return {}
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                return {}
            return data
        except Exception:
            return {}

    def get(self, *keys, default=None):
        cur = self.config
        for k in keys:
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur

    def get_default(self, key: str, default=None):
        return self.get("defaults", key, default=default)

    def get_api_key(self, service: str) -> Optional[str]:
        val = self.get("api_keys", service, default=None)
        if val:
            return str(val)
        env_key = f"GHOSTINTEL_{service.upper()}_API_KEY"
        return os.getenv(env_key)

    def get_proxy(self) -> Optional[str]:
        return self.get("proxy", "url", default=None)

    def use_tor(self) -> bool:
        return bool(self.get("proxy", "tor", default=False))

    def get_telegram_target(self) -> Optional[str]:
        return self.get("notifications", "telegram", default=None)

    def get_discord_webhook(self) -> Optional[str]:
        return self.get("notifications", "discord_webhook", default=None)

    def monitoring_enabled(self) -> bool:
        return bool(self.get("monitoring", "enabled", default=False))

    def monitoring_interval(self) -> int:
        return int(self.get("monitoring", "interval", default=300) or 300)

    @classmethod
    def ensure_dir(cls):
        cls.DEFAULT_PATH.parent.mkdir(parents=True, exist_ok=True)

    @classmethod
    def write_example(cls):
        cls.ensure_dir()
        path = cls.DEFAULT_PATH
        if path.exists():
            return path
        content = (
            "# GhostIntel configuration\n"
            "# Place API keys (optional) - tool works without these\n\n"
            "defaults:\n"
            "  deep: false\n"
            "  format: json          # json | html | txt | md | all\n"
            "  output_dir: output\n"
            "  timeout: 12\n"
            "  threads: 25\n"
            "  lang: en              # en | id\n\n"
            "monitoring:\n"
            "  enabled: false\n"
            "  interval: 300         # seconds between scans\n\n"
            "notifications:\n"
            "  telegram: null        # BOT_TOKEN:CHAT_ID\n"
            "  discord_webhook: null # full webhook URL\n\n"
            "proxy:\n"
            "  url: null             # http://host:port or socks5://host:port\n"
            "  tor: false            # route via local Tor (127.0.0.1:9050)\n\n"
            "api_keys:\n"
            "  hibp: null            # HaveIBeenPwned API key\n"
            "  virustotal: null\n"
            "  greynoise: null\n"
        )
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path


# Singleton
_config_instance: Optional[ConfigLoader] = None


def get_config() -> ConfigLoader:
    global _config_instance
    if _config_instance is None:
        _config_instance = ConfigLoader()
    return _config_instance
