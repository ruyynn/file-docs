#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Notifications (Telegram & Discord)"""

from typing import Optional
import asyncio

try:
    import aiohttp
except ImportError:  # pragma: no cover
    aiohttp = None  # type: ignore


class Notifier:
    """Send notifications via Telegram bot and/or Discord webhook.

    Targets are read from config (~/.ghostintel/config.yaml) or set explicitly.
    Telegram target format: "BOT_TOKEN:CHAT_ID"
    """

    def __init__(
        self,
        telegram_target: Optional[str] = None,
        discord_webhook: Optional[str] = None,
    ):
        from core.config import get_config

        cfg = get_config()
        self.telegram_target = telegram_target or cfg.get_telegram_target()
        self.discord_webhook = discord_webhook or cfg.get_discord_webhook()

    def enabled(self) -> bool:
        return bool(self.telegram_target or self.discord_webhook)

    async def send(self, message: str) -> dict:
        results = {}
        if self.telegram_target:
            results["telegram"] = await self._send_telegram(message)
        if self.discord_webhook:
            results["discord"] = await self._send_discord(message)
        return results

    def send_sync(self, message: str) -> dict:
        try:
            return asyncio.run(self.send(message))
        except RuntimeError:
            # Already in an event loop — make a fresh loop
            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(self.send(message))
            finally:
                loop.close()

    async def _send_telegram(self, message: str) -> bool:
        if aiohttp is None or not self.telegram_target:
            return False
        try:
            parts = self.telegram_target.split(":", 1)
            if len(parts) != 2:
                return False
            token, chat_id = parts
            url = f"https://api.telegram.org/bot{token.strip()}/sendMessage"
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json={
                        "chat_id": chat_id.strip(),
                        "text": message,
                        "parse_mode": "Markdown",
                        "disable_web_page_preview": True,
                    },
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as r:
                    return r.status == 200
        except Exception:
            return False

    async def _send_discord(self, message: str) -> bool:
        if aiohttp is None or not self.discord_webhook:
            return False
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.discord_webhook,
                    json={"content": message[:1900]},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as r:
                    return r.status in (200, 204)
        except Exception:
            return False


notifier = Notifier()
