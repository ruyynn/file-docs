#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Internationalization (id/en)

Bahasa Indonesia dibuat sopan tapi tidak terlalu baku/formal dan
tidak terlalu gaul — fokus ke jelas dan enak dibaca.
"""

from __future__ import annotations
from typing import Dict


_STRINGS: Dict[str, Dict[str, str]] = {
    "en": {
        "app.title": "GhostIntel v3.0 — OSINT Framework",
        "app.tagline": "Public sources only · Educational use",
        "app.disclaimer": "For education & authorized security research only",
        "investigating": "Investigating",
        "deep_investigation": "Deep Investigation",
        "target": "Target",
        "type": "Type",
        "time": "Time",
        "running_modules": "Running modules",
        "correlating": "Correlating intelligence",
        "no_results": "No results found",
        "no_target": "No target specified",
        "report_saved": "Report saved",
        "reports_saved": "Reports saved",
        "batch_summary": "Batch Summary",
        "total_targets": "Total targets",
        "successful": "Successful",
        "failed": "Failed",
        "interrupted": "Interrupted",
        "fatal": "Fatal",
        "monitor_started": "Monitoring started",
        "monitor_stopped": "Monitoring stopped",
        "monitor_detected_change": "Change detected for target",
        "monitor_no_change": "No changes detected",
        "new_profiles_found": "New profiles found",
        "check_complete": "Check complete",
        "version": "Version",
        "author": "Author",
        "github": "GitHub",
        "license": "License",
        "features": "Features",
        "language_set": "Language set to English",
        "config_loaded": "Config loaded from",
        "config_not_found": "No config file found, using defaults",
        "proxy_in_use": "Using proxy",
        "tor_enabled": "Tor routing enabled",
        "api_key_loaded": "API key loaded for",
        "no_api_key": "No API key — running in public-source mode",
        "update_available": "Update available",
        "up_to_date": "You're using the latest version",
        "version_check_failed": "Could not check for updates",
        "support_message": "Support the project at https://saweria.co/Ruyynn",
        "educational_notice": "This tool is for educational purposes only",
        "credit_message": "Created by Ruyynn",
    },
    "id": {
        "app.title": "GhostIntel v3.0 — OSINT Framework",
        "app.tagline": "Sumber publik saja · Untuk edukasi",
        "app.disclaimer": "Khusus edukasi & riset keamanan yang berizin",
        "investigating": "Memeriksa",
        "deep_investigation": "Investigasi Mendalam",
        "target": "Target",
        "type": "Tipe",
        "time": "Waktu",
        "running_modules": "Menjalankan modul",
        "correlating": "Menghubungkan data",
        "no_results": "Tidak ada hasil ditemukan",
        "no_target": "Target belum ditentukan",
        "report_saved": "Laporan tersimpan",
        "reports_saved": "Laporan tersimpan",
        "batch_summary": "Ringkasan Batch",
        "total_targets": "Total target",
        "successful": "Berhasil",
        "failed": "Gagal",
        "interrupted": "Dibatalkan",
        "fatal": "Fatal",
        "monitor_started": "Monitoring dimulai",
        "monitor_stopped": "Monitoring dihentikan",
        "monitor_detected_change": "Ada perubahan pada target",
        "monitor_no_change": "Belum ada perubahan",
        "new_profiles_found": "Profil baru ditemukan",
        "check_complete": "Pemeriksaan selesai",
        "version": "Versi",
        "author": "Pembuat",
        "github": "GitHub",
        "license": "Lisensi",
        "features": "Fitur",
        "language_set": "Bahasa diatur ke Indonesia",
        "config_loaded": "Config dimuat dari",
        "config_not_found": "Config belum ada, pakai pengaturan default",
        "proxy_in_use": "Memakai proxy",
        "tor_enabled": "Routing Tor aktif",
        "api_key_loaded": "API key dimuat untuk",
        "no_api_key": "Tanpa API key — pakai sumber publik saja",
        "update_available": "Versi baru tersedia",
        "up_to_date": "Kamu sudah pakai versi terbaru",
        "version_check_failed": "Gagal mengecek update",
        "support_message": "Dukung proyek ini di https://saweria.co/Ruyynn",
        "educational_notice": "Tool ini hanya untuk tujuan edukasi",
        "credit_message": "Dibuat oleh Ruyynn",
    },
}


class I18n:
    def __init__(self, lang: str = "en"):
        self.lang = lang if lang in _STRINGS else "en"

    def set_lang(self, lang: str):
        if lang in _STRINGS:
            self.lang = lang

    def t(self, key: str, **kwargs) -> str:
        s = _STRINGS.get(self.lang, _STRINGS["en"]).get(key)
        if s is None:
            s = _STRINGS["en"].get(key, key)
        if kwargs:
            try:
                return s.format(**kwargs)
            except Exception:
                return s
        return s

    @staticmethod
    def available() -> list:
        return list(_STRINGS.keys())


i18n = I18n("en")
