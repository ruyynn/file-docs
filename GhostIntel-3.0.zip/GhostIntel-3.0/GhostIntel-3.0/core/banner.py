#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Banner"""

import os
import sys
import time
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box
from rich.theme import Theme
from rich.progress import Progress, SpinnerColumn, TextColumn

custom_theme = Theme({
    "info":      "dim cyan",
    "warning":   "yellow",
    "danger":    "bold red",
    "success":   "bold green",
    "ghost":     "bold magenta",
    "highlight": "bold blue",
    "dim":       "dim white",
    "accent":    "bold cyan",
})

console = Console(theme=custom_theme)

VERSION = "3.0.0"
AUTHOR = "Ruyynn"
GITHUB = "https://github.com/ruyynn"
SAWERIA = "https://saweria.co/Ruyynn"

BANNER = r"""
       ▄████  ██░ ██  ▒█████   ██████ ▄▄▄█████▓
      ██▒ ▀█▒▓██░ ██▒▒██▒  ██▒▒██    ▒ ▓  ██▒ ▓▒
     ▒██░▄▄▄░▒██▀▀██░▒██░  ██▒░ ▓██▄   ▒ ▓██░ ▒░
     ░▓█  ██▓░▓█ ░██ ▒██   ██░  ▒   ██▒░ ▓██▓ ░
     ░▒▓███▀▒░▓█▒░██▓░ ████▓▒░▒██████▒▒  ▒██▒ ░
      ░▒   ▒  ▒ ░░▒░▒░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░  ▒ ░░
       ░   ░  ▒ ░▒░ ░  ░ ▒ ▒░ ░ ░▒  ░ ░    ░
     ░ ░   ░  ░  ░░ ░░ ░ ░ ▒  ░  ░  ░    ░
           ░  ░  ░  ░    ░ ░        ░
"""

SMALL_BANNER = """
╔══════════════════════════════════════╗
║  GHOSTINTEL v3.0 - OSINT Framework   ║
║   Public Sources · Educational Use   ║
╚══════════════════════════════════════╝
"""

LINE_BANNER = "GHOSTINTEL v3.0 - Advanced OSINT Framework"


def show_banner():
    os.system('cls' if os.name == 'nt' else 'clear')

    for line in BANNER.split('\n'):
        if line.strip():
            if any(c in line for c in ['█', '▄', '▒', '░', '▓', '▀']):
                console.print(f"[bold magenta]{line}[/bold magenta]")
            else:
                console.print(line)

    console.print(Panel.fit(
        "[bold cyan]G H O S T I N T E L[/bold cyan]  [dim]•[/dim]  "
        "[bold white]v3.0 OSINT Framework[/bold white]\n"
        "[dim]Public Sources · Optional API Keys · Educational Use[/dim]\n"
        "[yellow]For education & authorized security research only[/yellow]",
        border_style="magenta",
        box=box.HEAVY,
    ))

    console.print(
        "[bold cyan]Commands:[/bold cyan]  "
        "[green]-u USERNAME[/green]  [green]-e EMAIL[/green]  "
        "[green]-p PHONE[/green]  [green]-d DOMAIN[/green]  "
        "[green]-i IP[/green]  [bold yellow]-web[/bold yellow]  "
        "[green]--batch FILE[/green]\n"
        f"[dim]GitHub: {GITHUB}  ·  Support: {SAWERIA}[/dim]"
    )
    console.print()


def show_small_banner():
    console.print(SMALL_BANNER, style="bold cyan")


def show_loading_banner():
    console.clear()
    console.print("[bold magenta]GHOSTINTEL v3.0[/bold magenta] - [dim]Initializing...[/dim]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
        console=console
    ) as progress:
        progress.add_task(description="[cyan]Loading modules...[/cyan]", total=None)
        time.sleep(0.5)

    console.clear()
    show_banner()


def get_banner_text() -> str:
    return f"""GhostIntel v3.0 - OSINT Framework
    Public Sources · Optional API Keys · Educational Use Only
    GitHub: {GITHUB}
    """


def get_banner_rich() -> Text:
    text = Text()
    text.append("GHOSTINTEL", style="bold magenta")
    text.append(" v3.0 ", style="bold white")
    text.append("• ", style="dim")
    text.append("OSINT Framework", style="cyan")
    return text


def print_header(title: str, subtitle: str = "", icon: str = "›"):
    console.print()
    console.print(Panel(
        Text(f"{icon} {title}", style="bold cyan", justify="center"),
        subtitle=subtitle if subtitle else None,
        box=box.HEAVY,
        border_style="cyan",
        padding=(1, 2)
    ))
    console.print()


def print_divider(char: str = "─", length: int = 50):
    console.print(f"[dim]{char * length}[/dim]")


def print_entity_summary(entity_type: str, count: int, icon: str = "•"):
    if count > 0:
        console.print(f"  {icon} [cyan]{entity_type.title()}:[/cyan] [green]{count}[/green]")
    else:
        console.print(f"  {icon} [cyan]{entity_type.title()}:[/cyan] [dim]0[/dim]")


def animate_loading(message: str = "Loading", duration: float = 1.0):
    chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    start = time.time()
    i = 0

    while time.time() - start < duration:
        console.print(f"\r[cyan]{chars[i % len(chars)]}[/cyan] {message}...", end="")
        time.sleep(0.1)
        i += 1

    console.print("\r" + " " * 50, end="")
    console.print("\r", end="")


# ==================== CONVENIENCE FUNCTIONS ====================

def print_success(msg: str):
    console.print(f"[success]✓ {msg}[/success]")


def print_error(msg: str):
    console.print(f"[danger]✗ {msg}[/danger]")


def print_warning(msg: str):
    console.print(f"[warning]! {msg}[/warning]")


def print_info(msg: str):
    console.print(f"[info]i {msg}[/info]")


def print_debug(msg: str):
    if "--debug" in sys.argv:
        console.print(f"[dim]DEBUG: {msg}[/dim]")


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


# ==================== PROGRESS BARS ====================

def create_progress():
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console,
        transient=False
    )


def create_spinner():
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True
    )


__all__ = [
    'console', 'VERSION', 'AUTHOR', 'GITHUB', 'SAWERIA',
    'show_banner', 'show_small_banner', 'show_loading_banner',
    'get_banner_text', 'get_banner_rich',
    'print_header', 'print_divider', 'print_entity_summary',
    'animate_loading',
    'print_success', 'print_error', 'print_warning',
    'print_info', 'print_debug', 'clear_screen',
    'create_progress', 'create_spinner',
]
