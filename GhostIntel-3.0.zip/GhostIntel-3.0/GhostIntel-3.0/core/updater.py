#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Updater (checks GitHub releases)"""

from typing import Optional, Tuple
import json

try:
    import aiohttp
except ImportError:  # pragma: no cover
    aiohttp = None  # type: ignore

from core.utils import VERSION


GITHUB_RELEASES = "https://api.github.com/repos/ruyynn/GhostIntel/releases/latest"


def _parse_version(v: str) -> Tuple[int, int, int]:
    v = v.lstrip("vV").strip()
    parts = v.split(".")
    nums = []
    for p in parts[:3]:
        try:
            nums.append(int(p))
        except ValueError:
            nums.append(0)
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums)  # type: ignore


async def fetch_latest_release() -> Optional[dict]:
    if aiohttp is None:
        return None
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                GITHUB_RELEASES,
                timeout=aiohttp.ClientTimeout(total=8),
                headers={"Accept": "application/vnd.github+json"},
            ) as r:
                if r.status != 200:
                    return None
                return await r.json()
    except Exception:
        return None


async def check_for_update() -> Tuple[bool, Optional[str], Optional[str]]:
    """Returns (update_available, latest_version, release_url)."""
    data = await fetch_latest_release()
    if not data:
        return False, None, None
    latest = data.get("tag_name") or data.get("name") or ""
    latest = latest.lstrip("vV").strip()
    if not latest:
        return False, None, None
    cur = _parse_version(VERSION)
    new = _parse_version(latest)
    if new > cur:
        url = data.get("html_url") or data.get("tarball_url")
        return True, latest, url
    return False, latest, data.get("html_url")


def print_update_check():
    """Synchronous convenience for --update-check CLI flag."""
    from core.banner import console

    console.print("[cyan]Checking for updates...[/cyan]")
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # We're inside an existing loop — make a new one
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                avail, latest, url = ex.submit(asyncio.run, check_for_update()).result()
        else:
            avail, latest, url = loop.run_until_complete(check_for_update())
    except Exception:
        try:
            avail, latest, url = asyncio.run(check_for_update())
        except Exception:
            console.print("[red]Could not check for updates[/red]")
            return
    if not latest:
        console.print("[red]Could not retrieve latest version (check your network)[/red]")
        return
    if avail:
        console.print(f"[yellow]Update available: v{latest}[/yellow]")
        if url:
            console.print(f"[cyan]Get it at: {url}[/cyan]")
    else:
        console.print(f"[green]You're using the latest version (v{latest})[/green]")
