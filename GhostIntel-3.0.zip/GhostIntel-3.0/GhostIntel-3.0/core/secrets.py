#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Secret manager (env vars + config)"""

import os
from typing import Optional

from core.config import get_config


class SecretManager:
    """Retrieve API keys / tokens from environment or config file.

    Order of precedence:
      1. GHOSTINTEL_<SERVICE>_API_KEY environment variable
      2. ~/.ghostintel/config.yaml -> api_keys.<service>
      3. None
    """

    def get_api_key(self, service: str) -> Optional[str]:
        env_key = f"GHOSTINTEL_{service.upper()}_API_KEY"
        val = os.getenv(env_key)
        if val:
            return val.strip()
        return get_config().get_api_key(service)

    def require_api_key(self, service: str) -> str:
        key = self.get_api_key(service)
        if not key:
            raise RuntimeError(
                f"API key for '{service}' not found. "
                f"Set env {service.upper()}_API_KEY or GHOSTINTEL_{service.upper()}_API_KEY, "
                f"or add it under api_keys in ~/.ghostintel/config.yaml"
            )
        return key

    def has_api_key(self, service: str) -> bool:
        return bool(self.get_api_key(service))


secrets = SecretManager()
