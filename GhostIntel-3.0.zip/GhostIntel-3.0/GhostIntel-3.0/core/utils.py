#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Utils

Help system:
  -h / --help       : basic help (compact)
  -h -a / --help --all : full detailed help with explanations
"""

from rich.table import Table
from rich.panel import Panel
from rich import box
from rich.columns import Columns
from rich.text import Text
from core.banner import console, show_banner, VERSION, AUTHOR, GITHUB, SAWERIA

LICENSE = "MIT"


def print_help(show_all: bool = False):
    """Print help menu. Set show_all=True for the full detailed version."""
    show_banner()

    if not show_all:
        _print_basic_help()
    else:
        _print_full_help()


def _print_basic_help():
    """Compact help for everyday usage."""
    console.print(Panel.fit(
        f"[bold cyan]GHOSTINTEL v{VERSION}[/bold cyan]  [dim]·[/dim]  "
        "[dim]Use --help --all (or -h -a) for the full manual[/dim]",
        border_style="cyan"
    ))

    console.print("\n[bold yellow]Basic usage:[/bold yellow]")
    basic = [
        ("ghostintel.py -u USERNAME",     "Check username (230+ platforms)"),
        ("ghostintel.py -u USER --scrape", "Also extract profile data"),
        ("ghostintel.py -e EMAIL",        "Email + DNS + breach check"),
        ("ghostintel.py -p PHONE",        "Phone OSINT (10 countries)"),
        ("ghostintel.py -d DOMAIN",       "Domain DNS / HTTP / tech"),
        ("ghostintel.py -i IP",           "IP geolocation + risk score"),
        ("ghostintel.py -web",            "Launch web UI on :7331"),
        ("ghostintel.py --batch file.txt", "Batch scan from file"),
    ]
    for cmd, desc in basic:
        console.print(f"  [green]{cmd:<38}[/green] [dim]{desc}[/dim]")

    console.print("\n[bold yellow]Common options:[/bold yellow]")
    common = [
        ("--deep",                "Run all relevant modules"),
        ("--report",              "Save report (default JSON)"),
        ("--format all",          "Save JSON + HTML + TXT + MD"),
        ("--lang id",             "Bahasa Indonesia (en = English)"),
        ("--config",              "Use ~/.ghostintel/config.yaml"),
        ("--proxy URL",           "Route via HTTP/SOCKS5 proxy"),
        ("--tor",                 "Route via local Tor (9050)"),
        ("--credit",              "Show credits & support info"),
        ("-v / --version",        "Show version"),
    ]
    for cmd, desc in common:
        console.print(f"  [cyan]{cmd:<38}[/cyan] [dim]{desc}[/dim]")

    console.print(f"\n[dim]Full manual: [cyan]python ghostintel.py -h -a[/cyan]"
                  f"  ·  Support: {SAWERIA}[/dim]")


def _print_full_help():
    """Comprehensive help with explanations."""
    console.print(Panel.fit(
        f"[bold cyan]GHOSTINTEL v{VERSION}  —  COMPLETE MANUAL[/bold cyan]\n"
        "[dim]Public sources · Optional API keys · Educational use[/dim]",
        border_style="cyan"
    ))

    # ==================== TARGETS ====================
    console.print("\n[bold yellow]TARGETS[/bold yellow]")
    console.print("[dim]Pick one target type per run.[/dim]\n")
    targets = [
        ("-u, --username NAME",     "Check username across 230+ platforms"),
        ("-u NAME --scrape",        "Same as above + extract profile metadata"),
        ("-u NAME --availability",  "Inverse check — which platforms DON'T have the name yet"),
        ("-e, --email EMAIL",       "Email OSINT: MX/SPF/DMARC, breach check, gravatar"),
        ("-e EMAIL --breach-live",  "Live breach check via HIBP API (key optional)"),
        ("-p, --phone PHONE",       "Phone OSINT — 10 countries (ID/US/GB/MY/IN/AU/SG/PH/TH/VN)"),
        ("-p PHONE --format-all",   "Output every format variant (E.164, RFC3966, tel:, …)"),
        ("-d, --domain DOMAIN",     "Domain DNS + HTTP + tech detection"),
        ("-d DOMAIN --domain-history",      "WHOIS + age + Wayback snapshots"),
        ("-d DOMAIN --domain-reputation",   "Blacklists / malware / phishing / SSL grade"),
        ("-i, --ip IP",             "IP geolocation + RDAP + risk score"),
    ]
    for cmd, desc in targets:
        console.print(f"  [green]{cmd:<42}[/green] [dim]{desc}[/dim]")

    # ==================== INVESTIGATION ====================
    console.print("\n[bold yellow]INVESTIGATION MODES[/bold yellow]\n")
    inv = [
        ("--deep",            "Run all relevant modules for the target"),
        ("--report",          "Save a report (combine with --format)"),
        ("--format FMT",      "json | html | txt | md | all  (default: json)"),
        ("--output-dir DIR",  "Where reports go (default: output/)"),
        ("-o, --output FILE", "Custom output filename"),
        ("--compress",        "Gzip the JSON report"),
        ("--quiet",           "No terminal output (just save)"),
        ("--timeout SEC",     "Per-request timeout (default: 12)"),
        ("--threads N",       "Concurrent workers (default: 25)"),
        ("--debug",           "Verbose error output"),
    ]
    for cmd, desc in inv:
        console.print(f"  [cyan]{cmd:<42}[/cyan] [dim]{desc}[/dim]")

    # ==================== CONFIG & PROXY ====================
    console.print("\n[bold yellow]CONFIG / PROXY / SECURITY[/bold yellow]\n")
    sec = [
        ("--config",            "Load ~/.ghostintel/config.yaml (auto-detected if present)"),
        ("--config-init",       "Write a sample config to ~/.ghostintel/config.yaml"),
        ("--proxy URL",         "HTTP or SOCKS5 proxy  (e.g. socks5://127.0.0.1:9050)"),
        ("--tor",               "Shortcut for --proxy socks5://127.0.0.1:9050"),
        ("--api SERVICE=KEY",   "Pass an API key inline (e.g. --api hibp=xxxx)"),
        ("-api SERVICE=KEY",    "Same as --api (alias)"),
        ("--lang id|en",        "Interface language (default: en)"),
    ]
    for cmd, desc in sec:
        console.print(f"  [cyan]{cmd:<42}[/cyan] [dim]{desc}[/dim]")

    # ==================== MONITORING ====================
    console.print("\n[bold yellow]LIVE MONITORING & NOTIFICATIONS[/bold yellow]\n")
    mon = [
        ("--monitor",                "Re-scan target periodically and diff against baseline"),
        ("--interval SEC",           "Seconds between monitor scans (min 60, default 300)"),
        ("--notify-telegram",        "Send change notifications to Telegram"),
        ("--notify-discord URL",     "Send to a Discord webhook"),
        ("--breach-monitor",         "Re-check breaches periodically (use with -e)"),
        ("--darkweb-monitor",        "Re-check dark-web mentions (use with -u or -e)"),
        ("--darkweb-interval SEC",   "Seconds between dark-web scans"),
    ]
    for cmd, desc in mon:
        console.print(f"  [cyan]{cmd:<42}[/cyan] [dim]{desc}[/dim]")

    # ==================== BATCH ====================
    console.print("\n[bold yellow]BATCH PROCESSING[/bold yellow]\n")
    console.print("  [dim]One target per line in the batch file. Empty lines and # comments are skipped.[/dim]")
    console.print("  [green]python ghostintel.py --batch targets.txt --deep --format all[/green]")
    console.print("  [cyan]--batch-delay 2[/cyan]   [dim]Delay between scans (seconds)[/dim]")

    # ==================== WEB UI ====================
    console.print("\n[bold yellow]WEB UI[/bold yellow]\n")
    web = [
        ("-web, --web",         "Launch the local web dashboard"),
        ("--port 8080",         "Custom port (default: 7331)"),
        ("--no-browser",        "Don't auto-open the browser"),
    ]
    for cmd, desc in web:
        console.print(f"  [green]{cmd:<42}[/green] [dim]{desc}[/dim]")

    # ==================== META ====================
    console.print("\n[bold yellow]META COMMANDS[/bold yellow]\n")
    meta = [
        ("-h, --help",          "This basic help"),
        ("-h -a, --help --all", "This full manual"),
        ("-v, --version",       "Version info"),
        ("--update-check",      "Check GitHub for a newer release"),
        ("--credit",            "Credits & support info"),
        ("--changelog",         "Print changelog (v1.0 → v3.0)"),
    ]
    for cmd, desc in meta:
        console.print(f"  [cyan]{cmd:<42}[/cyan] [dim]{desc}[/dim]")

    # ==================== PHONE TABLE ====================
    console.print("\n[bold yellow]PHONE OSINT — 10 COUNTRIES[/bold yellow]")
    phone_table = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
    phone_table.add_column("Country", style="green")
    phone_table.add_column("Code", style="yellow")
    phone_table.add_column("Example", style="white")
    phone_table.add_column("Providers", style="dim")

    phone_data = [
        ("Indonesia",    "+62", "python ghostintel.py -p 08123456789",  "Telkomsel, Indosat, XL, Three, Smartfren"),
        ("USA",          "+1",  "python ghostintel.py -p +12125551234", "AT&T, Verizon, T-Mobile"),
        ("UK",           "+44", "python ghostintel.py -p +447700123456", "EE, O2, Vodafone, Three"),
        ("Malaysia",     "+60", "python ghostintel.py -p +60123456789", "Maxis, Celcom, DiGi, U Mobile"),
        ("India",        "+91", "python ghostintel.py -p +919876543210", "Airtel, Vi, Jio, BSNL"),
        ("Australia",    "+61", "python ghostintel.py -p +61412345678", "Telstra, Optus, Vodafone"),
        ("Singapore",    "+65", "python ghostintel.py -p +6581234567",  "Singtel, StarHub, M1, SIMBA"),
        ("Philippines",  "+63", "python ghostintel.py -p +639171234567", "Globe, Smart, DITO"),
        ("Thailand",     "+66", "python ghostintel.py -p +66812345678", "AIS, DTAC, True Move"),
        ("Vietnam",      "+84", "python ghostintel.py -p +84912345678", "Viettel, Vinaphone, Mobifone"),
    ]
    for row in phone_data:
        phone_table.add_row(*row)
    console.print(phone_table)

    # ==================== API KEYS (OPTIONAL) ====================
    console.print("\n[bold yellow]OPTIONAL API KEYS[/bold yellow]")
    console.print("[dim]Tool works fully without these. Add to enable extra sources.[/dim]\n")
    keys = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
    keys.add_column("Service", style="green")
    keys.add_column("Env var", style="yellow")
    keys.add_column("What it unlocks", style="white")
    keys.add_row("HaveIBeenPwned", "GHOSTINTEL_HIBP_API_KEY",  "Live breach + paste lookup")
    keys.add_row("VirusTotal",     "GHOSTINTEL_VIRUSTOTAL_API_KEY", "Domain malware reputation")
    keys.add_row("URLVoid",        "GHOSTINTEL_URLVOID_API_KEY",    "Additional blacklist data")
    keys.add_row("PhishTank",      "GHOSTINTEL_PHISHTANK_API_KEY",  "Phishing URL verification")
    keys.add_row("GreyNoise",      "GHOSTINTEL_GREYNOISE_API_KEY",  "IP noise/scanner classification")
    console.print(keys)
    console.print("\n[dim]Or set them under [cyan]api_keys:[/cyan] in ~/.ghostintel/config.yaml[/dim]")

    # ==================== EXAMPLES ====================
    console.print("\n[bold green]EXAMPLES[/bold green]")
    examples = [
        ("# Username + scrape + all formats",
         "python ghostintel.py -u ryan --scrape --format all"),
        ("# Email live breach check via HIBP",
         "python ghostintel.py -e user@gmail.com --breach-live --report"),
        ("# Phone (Indonesia), all output formats",
         "python ghostintel.py -p 08123456789 --format-all"),
        ("# Domain deep + history + reputation",
         "python ghostintel.py -d example.com --deep --format all"),
        ("# Username availability (which platforms are free)",
         "python ghostintel.py -u ryan --availability"),
        ("# Batch scan with proxy",
         "python ghostintel.py --batch targets.txt --proxy socks5://127.0.0.1:9050"),
        ("# Live monitor + Telegram alerts",
         "python ghostintel.py -u ryan --monitor --interval 60 --notify-telegram"),
        ("# Dark-web mention check (beta)",
         "python ghostintel.py -u ryan --darkweb-monitor --darkweb-interval 120"),
        ("# Bahasa Indonesia output",
         "python ghostintel.py -d example.com --deep --lang id"),
    ]
    for desc, cmd in examples:
        console.print(f"  [dim]{desc}[/dim]")
        console.print(f"  [cyan]{cmd}[/cyan]")

    # ==================== DISCLAIMER ====================
    console.print(Panel(
        "[yellow]LEGAL & ETHICAL DISCLAIMER[/yellow]\n\n"
        "GhostIntel is built for [bold]educational purposes[/bold] and authorized "
        "security research only.\n"
        "• Investigate only targets you own or have explicit permission to test.\n"
        "• All data is sourced from public records (DNS, RDAP, public websites, "
        "public breach databases).\n"
        "• Do NOT use for doxing, stalking, harassment, or any unlawful activity.\n\n"
        "[dim]By using this tool you accept full responsibility for compliance with "
        "all applicable laws. The author is not liable for any misuse.[/dim]",
        border_style="red",
        box=box.HEAVY,
        padding=(1, 2)
    ))

    console.print(f"\n[dim]Need help? Visit [cyan]{GITHUB}[/cyan] · "
                  f"Support the project: [cyan]{SAWERIA}[/cyan][/dim]")


def print_version():
    console.print(f"\n[bold cyan]GhostIntel v{VERSION}[/bold cyan]")
    console.print(f"[dim]   Author : {AUTHOR}[/dim]")
    console.print(f"[dim]   GitHub : {GITHUB}[/dim]")
    console.print(f"[dim]   License: {LICENSE}[/dim]")
    console.print(f"[dim]   Python : {__import__('sys').version.split()[0]}[/dim]")
    console.print()
    console.print("[green]Features:[/green]")
    console.print("  • 230+ Username Platforms (with optional scrape)")
    console.print("  • 10 Country Phone OSINT (added TH + VN)")
    console.print("  • Email + Live Breach Check (HIBP optional)")
    console.print("  • Domain DNS, Tech Stack, History, Reputation")
    console.print("  • IP Geolocation + Risk Scoring")
    console.print("  • Dark-web paste monitoring (beta)")
    console.print("  • Live monitoring + Telegram/Discord alerts")
    console.print("  • Config file (~/.ghostintel/config.yaml)")
    console.print("  • HTTP/SOCKS5 proxy + Tor support")
    console.print("  • Multi-language (English / Bahasa Indonesia)")
    console.print("  • Web UI dashboard")
    console.print("  • Batch processing + multi-format reports")


def print_credit():
    """Show author credit and support info."""
    console.print()
    console.print(Panel.fit(
        f"[bold magenta]GhostIntel v{VERSION}[/bold magenta]\n"
        f"[dim]OSINT Framework · Public Sources · Educational Use[/dim]\n\n"
        f"[cyan]Author :[/cyan] [bold]{AUTHOR}[/bold]\n"
        f"[cyan]GitHub :[/cyan] {GITHUB}\n"
        f"[cyan]License:[/cyan] {LICENSE}\n\n"
        f"[yellow]Support the project:[/yellow]\n"
        f"  Saweria: {SAWERIA}\n\n"
        f"[dim]Built for the cybersecurity community.[/dim]\n"
        f"[dim]If this tool helped you, consider giving it a star on GitHub.[/dim]",
        border_style="magenta",
        box=box.HEAVY,
    ))


def print_changelog():
    """Print changelog from v1.0.0 to v3.0.0."""
    changelog_path = Path(__file__).parent.parent / "CHANGELOG.md"
    if not changelog_path.exists():
        console.print("[red]CHANGELOG.md not found[/red]")
        return
    text = changelog_path.read_text(encoding="utf-8")
    console.print()
    console.print(Panel(text, title="CHANGELOG", border_style="cyan", box=box.ROUNDED))


def sanitize_filename(text: str) -> str:
    import re
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', text)
    sanitized = sanitized.replace(' ', '_')
    sanitized = re.sub(r'_+', '_', sanitized)
    if len(sanitized) > 200:
        sanitized = sanitized[:200]
    return sanitized.strip('_')


def format_size(bytes_size: int) -> str:
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f} TB"


def parse_timeout(timeout_str: str) -> int:
    try:
        return int(timeout_str)
    except ValueError:
        return 12


def print_banner_small():
    console.print(f"[bold magenta]GHOST[cyan]INTEL[/cyan][/bold magenta] [dim]v{VERSION}[/dim]")


def get_version_info() -> dict:
    return {
        'version': VERSION,
        'author': AUTHOR,
        'github': GITHUB,
        'license': LICENSE,
        'python': __import__('sys').version.split()[0],
        'features': [
            '230+ Username Platforms (with scrape)',
            '10 Country Phone OSINT',
            'Email + Live Breach (HIBP optional)',
            'Domain DNS / History / Reputation',
            'IP Geolocation + Risk Scoring',
            'Dark-web monitoring (beta)',
            'Live monitoring + notifications',
            'Config file support',
            'Proxy + Tor support',
            'Multi-language (en/id)',
            'Web UI',
            'Batch processing',
            'Multi-format reports (JSON/HTML/TXT/MD)',
        ]
    }


# Keep VERSION constant available for older imports
from pathlib import Path
