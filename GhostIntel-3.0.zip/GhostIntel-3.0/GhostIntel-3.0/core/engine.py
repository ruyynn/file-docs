#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Main Engine"""

import asyncio
import aiohttp
import socket
from datetime import datetime
from typing import Dict, List, Optional, Any
from rich.table import Table
from rich.tree import Tree
from rich import box
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from core.banner import console
from core.detector import detector, Entity
from core.correlation import CorrelationEngine
from core.proxy import ProxyManager
from core.i18n import i18n
from modules.username import UsernameModule
from modules.email import EmailModule
from modules.phone import PhoneModule
from modules.domain import DomainModule
from modules.ip import IPModule
from modules.domain_history import DomainHistoryModule
from modules.domain_reputation import DomainReputationModule
from modules.breach_live import BreachLiveModule
from modules.darkweb import DarkWebModule


class GhostIntelEngine:
    """Main OSINT investigation engine - v3.0"""

    def __init__(self, timeout: int = 12, max_concurrent: int = 25,
                 proxy: Optional[str] = None, tor: bool = False,
                 scrape: bool = False, lang: str = "en"):
        self.timeout = timeout
        self.max_concurrent = max_concurrent
        self.proxy_mgr = ProxyManager(proxy_url=proxy, tor=tor)
        self.scrape = scrape
        self.session = None
        self.results = {}
        self.correlation = CorrelationEngine()
        self.modules = {}
        if lang:
            i18n.set_lang(lang)

    async def __aenter__(self):
        resolver = aiohttp.resolver.AsyncResolver(
            nameservers=["8.8.8.8", "1.1.1.1", "8.8.4.4"]
        )

        connector = self.proxy_mgr.build_connector(
            limit=self.max_concurrent,
            ssl=False,
            force_close=True,
            enable_cleanup_closed=True,
            resolver=resolver,
            ttl_dns_cache=300,
        )

        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=self.timeout),
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/124.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
                "Accept-Encoding": "gzip, deflate, br",
                "DNT": "1",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
            },
        )

        # Note: per-request proxy kwargs for HTTP proxies
        self._proxy_kwargs = self.proxy_mgr.request_kwargs()

        self.modules = {
            "username": UsernameModule(self.session, scrape=self.scrape),
            "email": EmailModule(self.session),
            "phone": PhoneModule(self.session),
            "domain": DomainModule(self.session),
            "ip": IPModule(self.session),
            "domain_history": DomainHistoryModule(self.session),
            "domain_reputation": DomainReputationModule(self.session),
            "breach_live": BreachLiveModule(self.session),
            "darkweb": DarkWebModule(self.session),
        }
        return self

    async def __aexit__(self, *args):
        if self.session and not self.session.closed:
            await self.session.close()

    async def investigate(self, target: str, target_type: str = None) -> Dict:
        if not target_type or target_type == "auto":
            entity = detector.detect(target)
            target_type = entity.type
            target = entity.normalized

        console.print(
            f"\n[cyan]🔍 {i18n.t('investigating')}: [bold]{target}[/bold] "
            f"([yellow]{target_type.upper()}[/yellow])[/cyan]"
        )

        # Map CLI types to internal module names
        mod_key = target_type
        if target_type == "domain_history":
            mod_key = "domain_history"
        elif target_type == "domain_reputation":
            mod_key = "domain_reputation"
        elif target_type == "breach_live":
            mod_key = "breach_live"
        elif target_type == "darkweb":
            mod_key = "darkweb"

        module = self.modules.get(mod_key)
        if not module:
            # Fallback: use type directly
            module = self.modules.get(target_type)
        if not module:
            console.print(f"[red]❌ No module for type: {target_type}[/red]")
            return {}

        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True, console=console,
            ) as progress:
                progress.add_task(description=f"Running {target_type} scan…", total=None)
                result = await module.scan(target)
            if result and not result.get("error"):
                self.results[target_type] = result
                return result
            elif result and result.get("error"):
                console.print(f"[red]❌ {result['error']}[/red]")
                return result
            else:
                console.print(f"[red]❌ {i18n.t('no_results')}[/red]")
                return {}
        except Exception as e:
            console.print(f"[red]❌ Error: {e}[/red]")
            return {}

    async def investigate_all(self, target: str, target_type: str = None) -> Dict[str, Any]:
        if not target_type or target_type == "auto":
            entity = detector.detect(target)
            target_type = entity.type
            target = entity.normalized

        console.print(f"\n[bold cyan]╔══ {i18n.t('deep_investigation')} ══╗[/bold cyan]")
        console.print(f"[white]{i18n.t('target')} :[/white] [bold yellow]{target}[/bold yellow]")
        console.print(f"[white]{i18n.t('type')}   :[/white] [bold green]{target_type.upper()}[/bold green]")
        console.print(f"[white]{i18n.t('time')}   :[/white] [dim]{datetime.now().strftime('%H:%M:%S')}[/dim]\n")

        module_map = {
            "username": ["username", "email", "breach_live"],
            "email": ["email", "domain", "breach_live"],
            "phone": ["phone"],
            "domain": ["domain", "ip", "domain_history", "domain_reputation"],
            "ip": ["ip", "domain"],
        }
        modules_to_run = module_map.get(target_type, list(self.modules.keys()))

        results = {}
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(), console=console,
        ) as progress:
            task = progress.add_task(
                f"[cyan]{i18n.t('running_modules')}…[/cyan]",
                total=len(modules_to_run),
            )

            for mod_name in modules_to_run:
                mod = self.modules.get(mod_name)
                if mod:
                    progress.update(task, description=f"[cyan]{mod_name}…[/cyan]")
                    try:
                        r = await mod.scan(target)
                        if r and r.get("data"):
                            results[mod_name] = r
                    except Exception as e:
                        console.print(f"  [red]✗ {mod_name}: {str(e)[:60]}[/red]")
                    progress.advance(task)
                    await asyncio.sleep(0.05)

        self.results = results
        if results:
            console.print(f"\n[cyan]🔄 {i18n.t('correlating')}…[/cyan]")
            self.results["_correlation"] = self.correlation.correlate(results)

        return self.results

    async def display_result(self, result: Dict):
        if not result or result.get("error"):
            return
        mod = result.get("module", "")
        data = result.get("data", {})
        fn = {
            "username": self._show_username,
            "email": self._show_email,
            "phone": self._show_phone,
            "domain": self._show_domain,
            "ip": self._show_ip,
            "domain_history": self._show_domain_history,
            "domain_reputation": self._show_domain_reputation,
            "breach_live": self._show_breach_live,
            "darkweb": self._show_darkweb,
        }.get(mod)
        if fn:
            fn(data)

    async def display_summary(self, results: Dict):
        console.print("\n[bold cyan]═══ INVESTIGATION SUMMARY ═══[/bold cyan]\n")
        t = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
        t.add_column("Module"); t.add_column("Status"); t.add_column("Key Findings")

        for name, result in results.items():
            if name.startswith("_"):
                continue
            if result and result.get("data"):
                d = result["data"]
                if name == "username":
                    findings = f"{d.get('total_found',0)} platforms found"
                elif name == "email":
                    findings = (f"{len(d.get('mx_records',[]))} MX | "
                                f"SPF={'✓' if d.get('spf') else '✗'} | "
                                f"DMARC={'✓' if d.get('dmarc') else '✗'}")
                elif name == "phone":
                    findings = (f"{d.get('provider','?')} | "
                                f"{d.get('country','?')} | "
                                f"{d.get('line_type','?')}")
                elif name == "domain":
                    findings = (f"IP={','.join(d.get('ip_addresses',[])[:2])} | "
                                f"{d.get('https_status') or d.get('http_status','?')}")
                elif name == "ip":
                    findings = (f"{d.get('city','?')}, {d.get('country','?')} | "
                                f"{d.get('isp','?')}")
                elif name == "domain_history":
                    findings = (f"age={d.get('age_years','?')}y | "
                                f"registrar={d.get('registrar','?')}")
                elif name == "domain_reputation":
                    findings = (f"score={d.get('reputation_score','?')} | "
                                f"risk={d.get('risk_level','?')}")
                elif name == "breach_live":
                    findings = (f"breaches={d.get('total_breaches',0)} | "
                                f"risk={d.get('risk_level','?')}")
                elif name == "darkweb":
                    findings = (f"hits={d.get('total_hits',0)} | "
                                f"risk={d.get('risk_level','?')}")
                else:
                    findings = "Data found"
                t.add_row(name.upper(), "[green]✓ OK[/green]", findings)
            else:
                t.add_row(name.upper(), "[red]✗ None[/red]", "—")

        console.print(t)

        if "_correlation" in results:
            corr = results["_correlation"]
            entities = corr.get("entities", {})
            if entities:
                console.print("\n[bold yellow]🔗 Correlated Intel:[/bold yellow]")
                tree = Tree(f"[bold cyan]{corr.get('primary','Target')}[/bold cyan]")
                for etype, elist in entities.items():
                    if elist:
                        branch = tree.add(f"[yellow]{etype}[/yellow]")
                        for e in list(elist)[:5]:
                            branch.add(f"[dim]{e}[/dim]")
                console.print(tree)

    # ── Display helpers ──
    def _show_username(self, d):
        found = d.get("found", [])
        lines = [
            f"[bold cyan]👤 Username:[/bold cyan] [yellow]{d.get('username')}[/yellow]",
            f"[green]✓ Found on {len(found)} / {d.get('total_checked',0)} platforms[/green]",
        ]
        if d.get("scrape_mode"):
            lines.append("[dim]scrape mode: profile metadata extracted[/dim]")
        for p in found[:15]:
            lines.append(f"  [cyan]•[/cyan] [white]{p['platform']:<20}[/white] [dim]{p['url']}[/dim]")
        if len(found) > 15:
            lines.append(f"  [dim]… and {len(found)-15} more[/dim]")
        console.print(Panel("\n".join(lines), title="USERNAME OSINT",
                            border_style="cyan", box=box.HEAVY_EDGE))

    def _show_email(self, d):
        lines = [
            f"[bold cyan]📧 Email:[/bold cyan] [yellow]{d.get('email')}[/yellow]",
            f"[white]Domain    :[/white] {d.get('domain')}",
            f"[white]MX Records:[/white] {len(d.get('mx_records',[]))} found",
            f"[white]SPF       :[/white] {'[green]✓ Present[/green]' if d.get('spf') else '[red]✗ Missing[/red]'}",
            f"[white]DMARC     :[/white] {'[green]✓ Present[/green]' if d.get('dmarc') else '[yellow]✗ Missing[/yellow]'}",
            f"[white]Disposable:[/white] {'[red]Yes[/red]' if d.get('disposable') else '[green]No[/green]'}",
            f"[white]Gravatar  :[/white] {'[green]✓[/green]' if d.get('gravatar') else 'Not found'}",
        ]
        if d.get("breach_hint"):
            lines.append(f"[white]Breach    :[/white] [yellow]{d['breach_hint']}[/yellow]")
        console.print(Panel("\n".join(lines), title="EMAIL OSINT",
                            border_style="magenta", box=box.HEAVY_EDGE))

    def _show_phone(self, d):
        lines = [
            f"[bold cyan]📱 Phone:[/bold cyan] [yellow]{d.get('input')}[/yellow]",
            f"[white]International:[/white] [green]{d.get('international')}[/green]",
            f"[white]Country      :[/white] {d.get('country')} ({d.get('country_iso')})",
            f"[white]Provider     :[/white] [cyan]{d.get('provider','Unknown')}[/cyan]",
            f"[white]Type         :[/white] {d.get('line_type')}",
            f"[white]Timezone     :[/white] {', '.join(d.get('timezones',[])[:2]) or '—'}",
            f"[white]Mobile       :[/white] {'[green]Yes[/green]' if d.get('is_mobile') else 'No'}",
        ]
        if d.get("whatsapp_link"):
            lines.append(f"[white]WhatsApp     :[/white] [green]{d['whatsapp_link']}[/green]")
        fmts = d.get("formats", {})
        if fmts:
            lines.append("[white]Formats      :[/white]")
            for k, v in list(fmts.items())[:5]:
                lines.append(f"  [dim]{k:<14} : {v}[/dim]")
        console.print(Panel("\n".join(lines), title="PHONE OSINT",
                            border_style="green", box=box.HEAVY_EDGE))

    def _show_domain(self, d):
        lines = [
            f"[bold cyan]🌐 Domain:[/bold cyan] [yellow]{d.get('domain')}[/yellow]",
            f"[white]IPv4         :[/white] {', '.join(d.get('ip_addresses',[])[:3]) or '[red]None[/red]'}",
            f"[white]Nameservers  :[/white] {', '.join(d.get('nameservers',[])[:3]) or '—'}",
            f"[white]MX Records   :[/white] {len(d.get('mx_records',[]))}",
            f"[white]HTTPS status :[/white] {d.get('https_status') or '—'}",
            f"[white]Server       :[/white] {d.get('server_header') or '—'}",
            f"[white]Title        :[/white] {(d.get('title') or '—')[:60]}",
        ]
        if d.get("technologies"):
            lines.append(f"[white]Tech stack   :[/white] [cyan]{', '.join(d['technologies'])}[/cyan]")
        console.print(Panel("\n".join(lines), title="DOMAIN OSINT",
                            border_style="yellow", box=box.HEAVY_EDGE))

    def _show_ip(self, d):
        lines = [
            f"[bold cyan]🌍 IP:[/bold cyan] [yellow]{d.get('ip')}[/yellow]",
            f"[white]Country   :[/white] {d.get('country','?')} ({d.get('country_code','?')})",
            f"[white]City      :[/white] {d.get('city','—')}",
            f"[white]ISP       :[/white] {d.get('isp','—')}",
            f"[white]ASN       :[/white] {d.get('asn','—')} {d.get('asn_name','')}",
            f"[white]Risk      :[/white] [yellow]{d.get('risk_score','?')}/100[/yellow]",
        ]
        console.print(Panel("\n".join(lines), title="IP OSINT",
                            border_style="yellow", box=box.HEAVY_EDGE))

    def _show_domain_history(self, d):
        lines = [
            f"[bold cyan]📜 Domain:[/bold cyan] [yellow]{d.get('domain')}[/yellow]",
            f"[white]Registrar    :[/white] {d.get('registrar','—')}",
            f"[white]Created      :[/white] {d.get('creation_date','—')}",
            f"[white]Expires      :[/white] {d.get('expiration_date','—')}",
            f"[white]Age          :[/white] [cyan]{d.get('age_years','?')} years[/cyan]",
            f"[white]Expires in   :[/white] {d.get('expires_in_days','?')} days",
            f"[white]Archive total:[/white] {d.get('archive_total','0')} snapshots",
        ]
        console.print(Panel("\n".join(lines), title="DOMAIN HISTORY",
                            border_style="cyan", box=box.HEAVY_EDGE))

    def _show_domain_reputation(self, d):
        risk = d.get("risk_level", "unknown")
        risk_color = {"critical": "red", "high": "red", "medium": "yellow",
                      "low": "green", "minimal": "green"}.get(risk, "white")
        lines = [
            f"[bold cyan]🛡️ Domain:[/bold cyan] [yellow]{d.get('domain')}[/yellow]",
            f"[white]Reputation   :[/white] [{risk_color}]{d.get('reputation_score','?')}/100 ({risk})[/{risk_color}]",
            f"[white]Safe         :[/white] {'[green]Yes[/green]' if d.get('is_safe') else '[red]No[/red]'}",
            f"[white]Blacklists   :[/white] {', '.join(d.get('blacklist_hits',[])) or 'None'}",
            f"[white]SSL grade    :[/white] {d.get('ssl_grade',{}).get('grade','—')}",
        ]
        console.print(Panel("\n".join(lines), title="DOMAIN REPUTATION",
                            border_style="red", box=box.HEAVY_EDGE))

    def _show_breach_live(self, d):
        lines = [
            f"[bold cyan]🔓 Email:[/bold cyan] [yellow]{d.get('email')}[/yellow]",
            f"[white]Total breaches:[/white] [red]{d.get('total_breaches',0)}[/red]",
            f"[white]Risk score    :[/white] [yellow]{d.get('risk_score','?')}/100[/yellow]",
            f"[white]Risk level    :[/white] {d.get('risk_level','?')}",
            f"[white]HIBP API used :[/white] {d.get('hibp_available')}",
        ]
        breaches = d.get("breaches", [])[:5]
        if breaches:
            lines.append("[white]Recent breaches:[/white]")
            for b in breaches:
                name = b.get("Name") or b.get("name", "?")
                date = b.get("BreachDate") or b.get("year", "")
                lines.append(f"  [dim]• {name} ({date})[/dim]")
        console.print(Panel("\n".join(lines), title="BREACH CHECK",
                            border_style="red", box=box.HEAVY_EDGE))

    def _show_darkweb(self, d):
        lines = [
            f"[bold cyan]🌑 Target:[/bold cyan] [yellow]{d.get('target')}[/yellow]",
            f"[white]Total hits    :[/white] [yellow]{d.get('total_hits',0)}[/yellow]",
            f"[white]Risk level    :[/white] {d.get('risk_level','?')}",
            f"[white]Pastes found  :[/white] {len(d.get('pastes_found',[]))}",
            f"[white]Forum mentions:[/white] {len(d.get('forum_mentions',[]))}",
            f"[white]Onion mentions:[/white] {len(d.get('onion_mentions',[]))}",
            f"[dim]Note: {d.get('note','')}[/dim]",
        ]
        console.print(Panel("\n".join(lines), title="DARKWEB MONITORING (BETA)",
                            border_style="magenta", box=box.HEAVY_EDGE))
