#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GhostIntel v3.0 - Live monitoring (polls a target and notifies on changes)"""

import asyncio
import json
from datetime import datetime
from typing import Callable, Dict, Optional

from core.banner import console
from core.notifier import Notifier
from core.i18n import i18n


class Monitor:
    """Periodically re-scan a target and notify on changes."""

    def __init__(
        self,
        engine_factory: Callable[[], "object"],
        target: str,
        target_type: str,
        interval: int = 300,
        deep: bool = True,
        notifier: Optional[Notifier] = None,
    ):
        self.engine_factory = engine_factory
        self.target = target
        self.target_type = target_type
        self.interval = max(60, int(interval))
        self.deep = deep
        self.notifier = notifier or Notifier()
        self._baseline: Optional[Dict] = None
        self._stop = False

    def _summarize(self, results: Dict) -> Dict:
        """Extract a comparable summary from scan results."""
        out = {"platforms": set(), "ips": set(), "emails": set(), "breaches": set()}
        if not results:
            return out
        for mod_name, res in results.items():
            if mod_name.startswith("_") or not res:
                continue
            data = res.get("data", {}) if isinstance(res, dict) else {}
            if not isinstance(data, dict):
                continue
            if mod_name == "username":
                for p in data.get("found", []):
                    out["platforms"].add(p.get("platform"))
            elif mod_name == "domain":
                for ip in data.get("ip_addresses", []):
                    out["ips"].add(ip)
            elif mod_name == "email":
                bi = data.get("breach_info", {}) or {}
                for b in bi.get("breaches", []):
                    out["breaches"].add(b.get("name"))
        return out

    def _diff(self, prev: Dict, curr: Dict) -> Dict:
        diffs = {}
        for key in ("platforms", "ips", "emails", "breaches"):
            old = prev.get(key, set()) if prev else set()
            new = curr.get(key, set()) if curr else set()
            added = sorted(new - old)
            removed = sorted(old - new)
            if added or removed:
                diffs[key] = {"added": added, "removed": removed}
        return diffs

    async def _run_once(self) -> Dict:
        async with self.engine_factory() as engine:
            if self.deep:
                results = await engine.investigate_all(self.target, self.target_type)
            else:
                results = await engine.investigate(self.target, self.target_type)
                if results:
                    results = {self.target_type: results}
        return results or {}

    def _format_notification(self, diffs: Dict) -> str:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [f"*GhostIntel Monitor* — `{ts}`", f"Target: `{self.target}`"]
        any_change = False
        for key, d in diffs.items():
            if d["added"]:
                any_change = True
                lines.append(f"+ New {key}: {', '.join(map(str, d['added'][:10]))}")
            if d["removed"]:
                any_change = True
                lines.append(f"- Removed {key}: {', '.join(map(str, d['removed'][:10]))}")
        if not any_change:
            lines.append("No changes")
        return "\n".join(lines)

    async def run(self, max_iterations: Optional[int] = None):
        console.print(
            f"[cyan]{i18n.t('monitor_started')}: {self.target} "
            f"(interval={self.interval}s)[/cyan]"
        )
        if self.notifier.enabled():
            console.print(f"[dim]Notifications: ON[/dim]")
        else:
            console.print(f"[dim]Notifications: OFF (configure in ~/.ghostintel/config.yaml)[/dim]")

        it = 0
        try:
            while not self._stop:
                it += 1
                try:
                    results = await self._run_once()
                except Exception as e:
                    console.print(f"[red]Scan error: {e}[/red]")
                    results = {}

                summary = self._summarize(results)
                if self._baseline is None:
                    self._baseline = summary
                    console.print(
                        f"[green]Baseline set — "
                        f"{len(summary.get('platforms', set()))} platforms, "
                        f"{len(summary.get('ips', set()))} IPs[/green]"
                    )
                else:
                    diffs = self._diff(self._baseline, summary)
                    if diffs:
                        msg = self._format_notification(diffs)
                        console.print(f"[yellow]Change detected[/yellow]")
                        console.print(msg)
                        if self.notifier.enabled():
                            await self.notifier.send(msg)
                        # Update baseline
                        self._baseline = summary
                    else:
                        console.print(f"[dim]Check #{it}: no changes[/dim]")

                if max_iterations and it >= max_iterations:
                    break
                await asyncio.sleep(self.interval)
        except asyncio.CancelledError:
            pass
        console.print(f"[cyan]{i18n.t('monitor_stopped')}[/cyan]")

    def stop(self):
        self._stop = True
